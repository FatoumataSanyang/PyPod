@echo off
rem Double-click to build pyPod for Windows (see build_windows.ps1). Add -OneFile for a single pyPod.exe.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1" %*
echo.
pause
