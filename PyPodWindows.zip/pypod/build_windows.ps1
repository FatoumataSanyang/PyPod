# Builds a portable Windows version of pyPod.
#
#   .\build_windows.ps1            folder build  -> pyPod-windows-x64.zip  (unzip anywhere, run pyPod\pyPod.exe)
#   .\build_windows.ps1 -OneFile   single file   -> pyPod.exe              (slower to start, more antivirus false alarms)
#
# Needs Python 3.9+ and an internet connection (pip). Run from the pypod folder; or just double-click build_windows.bat.
param([switch]$OneFile)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
. "$PSScriptRoot\packaging\common.ps1"

$python = New-Venv "$PSScriptRoot\.build-venv"

Write-Host "==> Installing build dependencies"
Invoke-Checked $python @("-m", "pip", "install", "--quiet", "--upgrade", "pip")
Invoke-Checked $python @("-m", "pip", "install", "--quiet", "-r", "requirements.txt", "pyinstaller")
Install-Extras $python

Write-Host "==> Drawing the icon"
New-Item -ItemType Directory -Force -Path "build" | Out-Null
$env:QT_QPA_PLATFORM = "offscreen"
Invoke-Checked $python @("packaging\make_icon.py", "--ico", "build\pypod.ico")
Remove-Item Env:QT_QPA_PLATFORM

Write-Host "==> Freezing with PyInstaller"
$unused = @("QtWebEngineCore", "QtWebEngineWidgets", "QtWebEngineQuick", "QtWebView", "Qt3DCore", "Qt3DRender",
            "Qt3DInput", "Qt3DLogic", "Qt3DAnimation", "Qt3DExtras", "QtQuick3D", "QtCharts", "QtDataVisualization",
            "QtSql", "QtTest", "QtDesigner", "QtHelp", "QtPdf", "QtPdfWidgets", "QtBluetooth", "QtNfc", "QtSensors",
            "QtSerialPort", "QtRemoteObjects", "QtPositioning", "QtLocation", "QtScxml", "QtSpatialAudio", "QtGraphs")
$piArgs = @("--noconfirm", "--clean", "--windowed", "--name", "pyPod", "--icon", "build\pypod.ico")
foreach ($m in $unused) { $piArgs += @("--exclude-module", "PySide6.$m") }
if (Test-Path "assets") { $piArgs += @("--add-data", "assets;assets") }
if (Test-PyModule $python "miniaudio") { $piArgs += @("--collect-all", "miniaudio") }
if ($OneFile) { $piArgs += "--onefile" } else { $piArgs += "--onedir" }
$piArgs += "pypod.py"
Invoke-Checked $python (@("-m", "PyInstaller") + $piArgs)

if ($OneFile) {
    Copy-Item "dist\pyPod.exe" ".\pyPod.exe" -Force
    Write-Host ""
    Write-Host "Done: $PSScriptRoot\pyPod.exe"
} else {
    $zip = "$PSScriptRoot\pyPod-windows-x64.zip"
    if (Test-Path $zip) { Remove-Item $zip }
    Compress-Archive -Path "dist\pyPod" -DestinationPath $zip
    Write-Host ""
    Write-Host "Done: $zip"
    Write-Host "Unzip it anywhere and run pyPod\pyPod.exe (right-click it -> Pin to taskbar)."
}
