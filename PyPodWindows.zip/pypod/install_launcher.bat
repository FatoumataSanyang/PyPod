@echo off
rem Double-click to add a pyPod shortcut to the Start menu (see install_launcher.ps1). Add -Uninstall to remove it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_launcher.ps1" %*
echo.
pause
