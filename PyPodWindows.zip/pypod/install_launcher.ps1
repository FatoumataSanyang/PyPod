# Installs a "pyPod" Start-menu shortcut that runs pyPod from this folder (no build needed).
# Afterwards: Start menu -> right-click pyPod -> Pin to taskbar.     Remove it again with:  .\install_launcher.ps1 -Uninstall
param([switch]$Uninstall)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
. "$PSScriptRoot\packaging\common.ps1"

$shortcut = Join-Path ([Environment]::GetFolderPath("Programs")) "pyPod.lnk"
$dataDir = Join-Path $env:LOCALAPPDATA "pypod"
if ($Uninstall) {
    Remove-Item $shortcut -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $dataDir "pypod.ico") -ErrorAction SilentlyContinue
    Write-Host "Shortcut removed."
    exit 0
}

$python = New-Venv "$PSScriptRoot\.venv"
Write-Host "==> Installing dependencies"
Invoke-Checked $python @("-m", "pip", "install", "--quiet", "--upgrade", "pip")
Invoke-Checked $python @("-m", "pip", "install", "--quiet", "-r", "requirements.txt")
Install-Extras $python

Write-Host "==> Creating the shortcut"
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
$icon = Join-Path $dataDir "pypod.ico"
$env:QT_QPA_PLATFORM = "offscreen"
Invoke-Checked $python @("packaging\make_icon.py", "--ico", $icon)
Remove-Item Env:QT_QPA_PLATFORM

$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($shortcut)
$lnk.TargetPath = "$PSScriptRoot\.venv\Scripts\pythonw.exe"
$lnk.Arguments = '"' + "$PSScriptRoot\pypod.py" + '"'
$lnk.WorkingDirectory = $PSScriptRoot
$lnk.IconLocation = "$icon,0"
$lnk.Description = "pyPod - iPod-style music player"
$lnk.Save()

Write-Host ""
Write-Host "Done. Open the Start menu, search for pyPod, right-click it and choose 'Pin to taskbar'."
