# Shared helpers for the Windows scripts (dot-sourced; not meant to be run directly).

function Invoke-Checked {
    param([string]$Exe, [string[]]$Arguments)
    & $Exe @Arguments | Out-Host   # show the output, but keep it out of the function's return value
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed (exit code $LASTEXITCODE): $Exe $($Arguments -join ' ')"
    }
}

function Test-PyModule {
    param([string]$Python, [string]$Name)
    $old = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        & $Python -c "import $Name" *> $null
        return ($LASTEXITCODE -eq 0)
    } finally {
        $ErrorActionPreference = $old
    }
}

# Returns @{ Exe = ...; Args = @(...) } for a working Python 3.9+ ("py -3" launcher or python.exe on PATH).
function Find-Python {
    $candidates = @(
        @{ Name = "py";      Args = @("-3") },
        @{ Name = "python";  Args = @() },
        @{ Name = "python3"; Args = @() }
    )
    foreach ($c in $candidates) {
        $cmd = Get-Command $c.Name -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        $old = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        try {
            $pyArgs = $c.Args
            $out = & $cmd.Source @pyArgs -c "import sys; print(sys.version_info >= (3, 9))" 2>$null
        } catch {
            $out = $null
        } finally {
            $ErrorActionPreference = $old
        }
        if ($out -and ($out | Select-Object -First 1) -eq "True") {
            return @{ Exe = $cmd.Source; Args = $c.Args }
        }
    }
    throw "Python 3.9 or newer was not found. Install it from https://www.python.org/downloads/ (tick 'Add python.exe to PATH') and run this again."
}

function New-Venv {
    param([string]$Dir)
    $py = Find-Python
    if (-not (Test-Path "$Dir\Scripts\python.exe")) {
        Write-Host "==> Creating virtual environment ($Dir)"
        Invoke-Checked $py.Exe (@($py.Args) + @("-m", "venv", $Dir))
    }
    return "$Dir\Scripts\python.exe"
}

function Install-Extras {
    param([string]$Python)
    foreach ($extra in @("numpy", "miniaudio")) {
        & $Python -m pip install --quiet $extra
        if ($LASTEXITCODE -ne 0) {
            Write-Warning "$extra could not be installed (the visualizer will use a slower / more limited fallback)."
        }
    }
}
