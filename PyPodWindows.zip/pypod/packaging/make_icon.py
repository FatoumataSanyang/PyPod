#!/usr/bin/env python3
"""Draws the pyPod icon.

    make_icon.py OUTPUT.png          256x256 PNG
    make_icon.py --ico OUTPUT.ico    multi-size Windows icon
"""
import os
import struct
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

ICO_SIZES = (16, 24, 32, 48, 64, 128, 256)


def build_ico(blobs) -> bytes:
    """blobs: [(size, png_bytes), ...]  ->  the bytes of a .ico file with PNG-compressed images."""
    header = struct.pack("<HHH", 0, 1, len(blobs))
    offset = 6 + 16 * len(blobs)
    entries, data = b"", b""
    for size, png in blobs:
        entries += struct.pack("<BBBBHHII", size % 256, size % 256, 0, 0, 1, 32, len(png), offset + len(data))
        data += png
    return header + entries + data


def main() -> None:
    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtGui import QGuiApplication

    from pypod import draw_icon

    app = QGuiApplication([])  # noqa: F841  (Qt needs one to draw)
    args = sys.argv[1:]
    if args and args[0] == "--ico":
        out = args[1] if len(args) > 1 else "pypod.ico"
        blobs = []
        for size in ICO_SIZES:
            buf = QBuffer()
            buf.open(QIODevice.OpenModeFlag.WriteOnly)
            draw_icon(size).save(buf, "PNG")
            blobs.append((size, bytes(buf.data())))
        Path(out).write_bytes(build_ico(blobs))
    else:
        draw_icon(256).save(args[0] if args else "pypod.png")


if __name__ == "__main__":
    main()
