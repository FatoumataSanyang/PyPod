#!/usr/bin/env python3
"""pyPod - a desktop MP3 player styled after the 1st/2nd generation iPod.

* frameless, transparent, draggable, optional "always on top"
* painted click wheel: circular scroll gesture, MENU / PREV / NEXT / PLAY buttons, centre button
* LCD-style UI with menus, Now Playing screen, volume overlay and scrub mode
* recursive .mp3 scan, ID3 tags (mutagen), persistent JSON config

pyPod 2.0.  Run:  python3 pypod.py [--folder ~/Music] [--scale 1.25] [--on-top]
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import wave
from array import array
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import (
    QBrush,
    QColor,
    QConicalGradient,
    QFont,
    QFontDatabase,
    QFontMetrics,
    QGradient,
    QGuiApplication,
    QIcon,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QPolygonF,
    QRadialGradient,
)
from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer, QSoundEffect
from PySide6.QtWidgets import (QApplication, QColorDialog, QFileDialog, QInputDialog, QLineEdit, QMenu,
                               QWidget)

try:
    import mutagen
except ImportError:  # the app still runs, tags just fall back to file names
    mutagen = None
try:
    import numpy as np  # optional: makes the visualizer analysis much cheaper
except ImportError:
    np = None

APP_NAME = "pyPod"
IS_WIN = sys.platform == "win32"
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)  # no console flash for helper programs
AUDIO_EXTS = (".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".wav")
BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))

# --------------------------------------------------------------------------- config

def config_dir() -> Path:
    if IS_WIN:  # %APPDATA%\pypod
        return Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "pypod"
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "pypod"


CONFIG_DIR = config_dir()
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULTS = {
    "folder": "",
    "volume": 0.6,
    "always_on_top": False,
    "scale": 1.0,
    "repeat": "off",  # off | all | one
    "shuffle": False,
    "click_volume": 50,  # 0 / 25 / 50 / 85 / 100 (%), 0 = no clicks at all
    "click_engine": "Auto",  # Auto | Qt | System
    "pos": None,
    # appearance
    "skin": "White",
    "custom_color": "#2f7fd6",
    "rainbow": False,
    "rainbow_speed": "medium",  # slow | medium | fast
    "wheel_style": "match",  # match | white | black
    "lcd": "Classic",
    "opacity": 1.0,
    "shadow": True,
    "art": "Color",  # Color | LCD | Off
    "ticker": True,  # sliding "now playing" strip in menus
    "shake": True,  # shake the disc case when the disc slams in
    # visualizer (off by default)
    "viz": False,
    "viz_style": "Bars",  # Bars | Mirror | Wave | LED
    "viz_colors": "Cover",  # LCD | Rainbow | Fire | Ocean | Neon | Sunset | Cover
    "viz_bars": 24,  # 16 | 24 | 32
    "viz_gain": "Normal",  # Low | Normal | High
    "viz_peaks": True,
    "viz_smooth": "Normal",  # Snappy | Normal | Smooth
    # Discord Rich Presence
    "discord": False,
    "discord_client_id": "",
    "discord_image": "pypod",  # name of the art asset uploaded to your Discord application
    # controls
    "sensitivity": "normal",  # low | normal | high
}


def load_config() -> dict:
    cfg = dict(DEFAULTS)
    try:
        data = json.loads(CONFIG_FILE.read_text("utf-8"))
        if isinstance(data, dict):
            cfg.update(data)
            if "click_volume" not in data and data.get("clicker") is False:
                cfg["click_volume"] = 0  # an older version had the clicker switched off: keep it silent
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CONFIG_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(cfg, indent=2), "utf-8")
        tmp.replace(CONFIG_FILE)
    except OSError:
        pass


# --------------------------------------------------------------------------- library


@dataclass
class Track:
    path: str
    title: str
    artist: str
    album: str
    number: int = 0
    length: float = 0.0


def _first(tags, key: str, default: str = "") -> str:
    try:
        v = tags.get(key) if tags is not None else None
        if v:
            return str(v[0]).strip() or default
    except Exception:
        pass
    return default


def read_track(path: str) -> Track:
    title = Path(path).stem
    artist, album, number, length = "Unknown Artist", "Unknown Album", 0, 0.0
    if mutagen is not None:
        try:
            f = mutagen.File(path, easy=True)
            if f is not None:
                length = float(getattr(f.info, "length", 0.0) or 0.0)
                title = _first(f.tags, "title", title)
                artist = _first(f.tags, "artist", artist)
                album = _first(f.tags, "album", album)
                tn = _first(f.tags, "tracknumber", "0").split("/")[0].strip()
                number = int(tn) if tn.isdigit() else 0
        except Exception:
            pass
    return Track(path, title, artist, album, number, length)


def load_cover(path: str) -> Optional[bytes]:
    """Embedded cover art (ID3 / FLAC / MP4), else cover.jpg / folder.png ... next to the file."""
    if mutagen is not None:
        try:
            f = mutagen.File(path)
            if f is not None:
                pics = getattr(f, "pictures", None)
                if pics:
                    best = next((q for q in pics if q.type == 3), pics[0])
                    return bytes(best.data)
                tags = f.tags
                if tags is not None:
                    for k in list(tags.keys()):
                        if str(k).startswith("APIC"):
                            return bytes(tags[k].data)
                    covr = tags.get("covr") if hasattr(tags, "get") else None
                    if covr:
                        return bytes(covr[0])
        except Exception:
            pass
    folder = os.path.dirname(path)
    try:
        names = {n.lower(): n for n in os.listdir(folder)}
    except OSError:
        return None
    for base in ("cover", "folder", "front", "album", "albumart", "artwork"):
        for ext in (".jpg", ".jpeg", ".png"):
            if base + ext in names:
                try:
                    return Path(folder, names[base + ext]).read_bytes()
                except OSError:
                    pass
    return None


class Scanner(QThread):
    progress = Signal(int)
    done = Signal(list)

    def __init__(self, folder: str):
        super().__init__()
        self.folder = os.path.normpath(folder)

    def run(self):
        tracks: list[Track] = []
        for root, _dirs, files in os.walk(self.folder, followlinks=True):
            for fn in sorted(files):
                if fn.lower().endswith(AUDIO_EXTS):
                    tracks.append(read_track(os.path.normpath(os.path.join(root, fn))))
                    if len(tracks) % 10 == 0:
                        self.progress.emit(len(tracks))
        self.done.emit(tracks)


# --------------------------------------------------------------------------- menu model


@dataclass
class Item:
    label: str
    action: Optional[Callable[[], None]] = None
    arrow: bool = False
    value: Optional[Callable[[], str]] = None


class Screen:
    def __init__(self, title: str, items=None, kind: str = "menu", builder=None):
        self.title = title
        self.kind = kind  # "menu" | "now"
        self.builder = builder
        self.items: list[Item] = items or []
        self.sel = 0
        self.top = 0
        if builder:
            self.refresh()

    def refresh(self):
        if self.builder:
            self.items = self.builder()
        n = len(self.items)
        self.sel = max(0, min(self.sel, n - 1))
        self.top = max(0, min(self.top, max(0, n - IPod.VIS)))


# --------------------------------------------------------------------------- helpers

# LCD colour schemes: (background top, background bottom, ink, text-on-selection)
LCD_THEMES = {
    "Classic": ("#d6e2f3", "#b6c8e2", "#26334a", "#d9e5f5"),
    "Green": ("#d4eeb2", "#a8cd78", "#1f3a14", "#dcf2c0"),
    "Amber": ("#ffdc8e", "#f1ab36", "#4a2a00", "#ffe6b0"),
    "Mono": ("#f3f3f3", "#d6d6d6", "#202020", "#f3f3f3"),
    "Night": ("#1d2532", "#0f141c", "#8fd0ff", "#0f141c"),
    "Ruby": ("#2a0d0d", "#1a0606", "#ff6a5a", "#1a0606"),
}
INK = QColor(LCD_THEMES["Classic"][2])
LCD_HI = QColor(LCD_THEMES["Classic"][0])
LCD_LO = QColor(LCD_THEMES["Classic"][1])
LCD_TEXT_INV = QColor(LCD_THEMES["Classic"][3])


def apply_lcd(name: str) -> None:
    global INK, LCD_HI, LCD_LO, LCD_TEXT_INV
    hi, lo, ink, inv = LCD_THEMES.get(name, LCD_THEMES["Classic"])
    INK, LCD_HI, LCD_LO, LCD_TEXT_INV = QColor(ink), QColor(hi), QColor(lo), QColor(inv)


# Body skins: name -> (body colour, matching wheel colour, wheel label/icon colour)
SKINS = {
    "White": ("#eeeeee", "#eeeeee", "#7d7d7d"),
    "Silver": ("#c4c8ce", "#d3d6db", "#6c7075"),
    "Graphite": ("#52565c", "#40444a", "#a9adb3"),
    "Black": ("#2b2b2e", "#202023", "#a0a0a6"),
    "Red": ("#d03a35", "#b82e2a", "#f3d0ce"),
    "Orange": ("#f08a24", "#d9741a", "#fff0dd"),
    "Yellow": ("#f4cf2c", "#e1bb1c", "#6b5600"),
    "Green": ("#4cae4f", "#3d9440", "#e0f5e0"),
    "Mint": ("#8fdcc0", "#79c8ab", "#2d6b55"),
    "Blue": ("#2f7fd6", "#2568b4", "#dbe9fb"),
    "Navy": ("#26407a", "#1d3262", "#b9c8ea"),
    "Purple": ("#8a4fc6", "#7440ab", "#eadcf8"),
    "Pink": ("#f06aa8", "#dc558f", "#ffe0ef"),
}


def fmt_time(ms: int) -> str:
    s = int(max(0, ms) // 1000)
    return f"{s // 60}:{s % 60:02d}"


def pick_font_family() -> str:
    for ttf in list((BASE_DIR / "assets").glob("*.ttf")) + list((BASE_DIR / "assets").glob("*.otf")):
        QFontDatabase.addApplicationFont(str(ttf))
    fams = set(QFontDatabase.families())
    for cand in ("ChicagoFLF", "Chicago", "Silkscreen", "Espy Sans", "DejaVu Sans Mono",
                 "Liberation Mono", "Noto Sans Mono", "Consolas", "Lucida Console", "Courier New", "Monospace"):
        if cand in fams:
            return cand
    return QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont).family()


def make_click_wav(path: Path) -> None:
    rate = 22050
    n = int(rate * 0.012)
    rnd = random.Random(3)
    frames = array("h", (int(18000 * math.exp(-i / (n / 5)) * (rnd.random() * 2 - 1)) for i in range(n)))
    frames.extend([0] * int(rate * 0.08))  # silent tail: keeps the sound long enough for the audio server
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(frames.tobytes())


def make_thud_wav(path: Path) -> None:
    """A short low 'thump' with a noisy attack, played when the disc slams into its case."""
    rate = 22050
    n = int(rate * 0.20)
    rnd = random.Random(7)
    out = array("h")
    phase = 0.0
    for i in range(n):
        t = i / rate
        freq = 45.0 + 70.0 * math.exp(-t * 28.0)  # pitch drops fast
        phase += 2 * math.pi * freq / rate
        env = math.exp(-t * 20.0)
        noise = (rnd.random() * 2 - 1) * math.exp(-t * 90.0) * 0.5
        out.append(int(max(-1.0, min(1.0, (math.sin(phase) * 0.9 + noise) * env)) * 24000))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(out.tobytes())


def sfx_dir() -> Path:
    """A per-user folder for the generated click / thud files."""
    if IS_WIN:
        d = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()) / "pypod" / "sfx"
    else:  # the runtime dir is private to this user
        base = os.environ.get("XDG_RUNTIME_DIR")
        d = Path(base if base and os.access(base, os.W_OK) else tempfile.gettempdir()) / f"pypod-{os.getuid()}"
    d.mkdir(parents=True, exist_ok=True)
    return d


class Sfx:
    """A short UI sound with a per-play volume (0..1).

    Engines: "System" = pw-play / paplay / aplay, "Qt" = QSoundEffect, "Auto" = the system player when one
    exists (it is the more dependable route on PipeWire / PulseAudio desktops), otherwise Qt.
    """

    def __init__(self, wav: Path, volume: float = 1.0):
        self.wav = wav
        self.volume = volume
        self._procs: list = []
        self._reported = False
        self.fx: Optional[QSoundEffect] = None
        try:
            self.fx = QSoundEffect()
            self.fx.setSource(QUrl.fromLocalFile(str(wav)))
            self.fx.setVolume(volume)
        except Exception:
            self.fx = None
        self.exe: Optional[str] = None
        self.kind = ""
        if IS_WIN:
            try:
                import winsound  # noqa: F401  (standard library on Windows)

                self.exe, self.kind = "winsound", "winsound"
            except ImportError:
                pass
        else:
            for name in ("pw-play", "paplay", "aplay"):
                found = shutil.which(name)
                if found:
                    self.exe, self.kind = found, name
                    break

    def system_desc(self) -> str:
        if self.kind == "winsound":
            return "Windows winsound"
        return self.exe if self.exe else "none found (pw-play / paplay / aplay)"

    def qt_ready(self) -> bool:
        try:
            return self.fx is not None and self.fx.status() == QSoundEffect.Status.Ready
        except Exception:
            return False

    def _scaled(self, level: float) -> Path:
        """A copy of the wav at a lower amplitude, for players that have no volume option (aplay)."""
        pct = max(1, min(100, int(round(level * 100))))
        out = self.wav.with_name(f"{self.wav.stem}_{pct}.wav")
        try:
            if not out.exists() or out.stat().st_mtime < self.wav.stat().st_mtime:
                with wave.open(str(self.wav)) as r:
                    params, raw = r.getparams(), r.readframes(r.getnframes())
                smp = array("h")
                smp.frombytes(raw)
                g = pct / 100.0
                smp = array("h", (int(v * g) for v in smp))
                with wave.open(str(out), "wb") as w:
                    w.setnchannels(params.nchannels)
                    w.setsampwidth(params.sampwidth)
                    w.setframerate(params.framerate)
                    w.writeframes(smp.tobytes())
            return out
        except (OSError, wave.Error):
            return self.wav

    def _command(self, level: float) -> list:
        if self.kind == "pw-play":
            return [self.exe, f"--volume={level:.3f}", str(self.wav)]
        if self.kind == "paplay":
            return [self.exe, f"--volume={int(level * 65536)}", str(self.wav)]
        return [self.exe, "-q", str(self._scaled(level))]

    def _play_system(self, level: float) -> bool:
        if self.kind == "winsound":  # no volume option: play a copy of the wav at the wanted amplitude
            try:
                import winsound

                winsound.PlaySound(str(self._scaled(level)),
                                   winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
                return True
            except (ImportError, OSError, RuntimeError):
                return False
        self._procs = [q for q in self._procs if q.poll() is None]
        if len(self._procs) >= 6:  # never pile up processes while scrolling fast
            return True
        try:
            self._procs.append(subprocess.Popen(self._command(level), stdout=subprocess.DEVNULL,
                                                stderr=subprocess.DEVNULL, env=_clean_env(),
                                                creationflags=_NOWIN))
            return True
        except OSError:
            return False

    def play(self, engine: str = "Auto", level: Optional[float] = None) -> None:
        level = max(0.0, min(1.0, self.volume if level is None else level))
        if level <= 0.0:
            return
        if not self._reported:  # one line on the terminal, handy if the clicks are ever silent
            self._reported = True
            try:
                st = self.fx.status() if self.fx is not None else None
            except Exception:
                st = None
            print(f"pyPod: sound {self.wav.name}: Qt status={st}, system player={self.system_desc()}, "
                  f"engine={engine}", file=sys.stderr)
        if engine != "Qt" and self.exe and self._play_system(level):
            return
        if self.fx is not None and (engine == "Qt" or self.qt_ready()):
            self.fx.setVolume(level)
            self.fx.play()


def draw_icon(size: int = 256) -> QImage:
    """The pyPod application icon: a little iPod with a screen and a click wheel."""
    img = QImage(256, 256, QImage.Format.Format_ARGB32)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 12, 256, 244)
    g.setColorAt(0, QColor("#fbfbfb"))
    g.setColorAt(1, QColor("#d8d8d8"))
    p.setBrush(g)
    p.setPen(QPen(QColor("#8c8c8c"), 3))
    p.drawRoundedRect(QRectF(52, 12, 152, 232), 18, 18)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#4a4a4a"))
    p.drawRoundedRect(QRectF(66, 26, 124, 84), 6, 6)
    p.setBrush(QColor("#c5d5ea"))
    p.drawRoundedRect(QRectF(70, 30, 116, 76), 3, 3)
    p.setBrush(QColor("#26334a"))
    p.drawRect(QRectF(78, 80, 100, 8))
    c = QPointF(128, 178)
    p.setBrush(QColor("#ececec"))
    p.setPen(QPen(QColor("#9a9a9a"), 2))
    p.drawEllipse(c, 56, 56)
    p.setBrush(QColor("#fafafa"))
    p.drawEllipse(c, 42, 42)
    p.setBrush(QColor("#e8e8e8"))
    p.drawEllipse(c, 17, 17)
    p.end()
    if size != 256:
        img = img.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    return img


def poly(pts) -> QPolygonF:
    return QPolygonF([QPointF(x, y) for x, y in pts])


# --------------------------------------------------------------------------- visualizer engine


def _clean_env() -> dict:
    """Environment for host programs: a frozen (PyInstaller / AppImage) app must not leak its own libraries."""
    env = dict(os.environ)
    if "LD_LIBRARY_PATH_ORIG" in env:
        env["LD_LIBRARY_PATH"] = env["LD_LIBRARY_PATH_ORIG"]
    elif getattr(sys, "frozen", False):
        env.pop("LD_LIBRARY_PATH", None)
    return env


def decode_mono(path: str, rate: int = 22050):
    """The whole track as mono signed-16 samples at `rate`: miniaudio if installed, else the ffmpeg CLI."""
    try:
        import miniaudio

        d = miniaudio.decode_file(path, output_format=miniaudio.SampleFormat.SIGNED16, nchannels=1, sample_rate=rate)
        if len(d.samples) > 2048:
            return d.samples
    except Exception:
        pass
    exe = shutil.which("ffmpeg")
    if not exe:  # a copy placed next to pypod.exe / pypod.py also works
        for cand in (BASE_DIR / "ffmpeg.exe", BASE_DIR / "ffmpeg", BASE_DIR / "bin" / "ffmpeg.exe",
                     Path(sys.executable).resolve().parent / "ffmpeg.exe"):
            if cand.is_file():
                exe = str(cand)
                break
    if exe:
        try:
            r = subprocess.run(
                [exe, "-v", "error", "-nostdin", "-i", path, "-vn", "-f", "s16le", "-ac", "1", "-ar", str(rate), "-"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=180, env=_clean_env(),
                creationflags=_NOWIN)
            if r.returncode == 0 and len(r.stdout) > 4096:
                a = array("h")
                a.frombytes(r.stdout[: len(r.stdout) // 2 * 2])
                return a
        except (OSError, subprocess.SubprocessError):
            pass
    return None


class AudioAnalysis:
    """Spectrum of a decoded track, looked up by playback position (so it stays in sync through seeks)."""

    RATE = 22050
    F_LO, F_HI = 45.0, 10000.0

    def __init__(self, samples):
        self.n = len(samples)
        self.N = 1024 if np is not None else 384
        win = [0.5 - 0.5 * math.cos(2 * math.pi * i / (self.N - 1)) for i in range(self.N)]
        self.norm = sum(win) / 2.0  # an amplitude-A sine then reads as A
        if np is not None:
            self.x = np.frombuffer(samples, dtype=np.int16)
            self.win = np.asarray(win, dtype=np.float32)
        else:
            self.x = samples
            self.win = win
        self._layout: dict = {}

    def _bands_layout(self, nb: int):
        lay = self._layout.get(nb)
        if lay is None:
            ratio = (self.F_HI / self.F_LO) ** (1.0 / nb)
            edges = [self.F_LO * ratio ** i for i in range(nb + 1)]
            hz = self.RATE / self.N
            bins, centres = [], []
            for i in range(nb):
                b0 = int(edges[i] / hz)
                bins.append((b0, max(b0 + 1, int(edges[i + 1] / hz) + 1)))
                centres.append(math.sqrt(edges[i] * edges[i + 1]))
            tilt = [12.0 * i / max(1, nb - 1) for i in range(nb)]  # music loses ~3 dB per octave: even it out
            lay = self._layout[nb] = (bins, centres, tilt)
        return lay

    @staticmethod
    def _level(mag: float, tilt: float, gain_db: float) -> float:
        db = 20.0 * math.log10(mag + 1e-7) + tilt + gain_db
        return max(0.0, min(1.0, (db + 86.0) / 70.0))

    def bands(self, pos: float, nb: int, gain_db: float = 0.0) -> list:
        """`nb` levels (0..1, log-spaced from 45 Hz to 10 kHz) at `pos` seconds."""
        bins, centres, tilt = self._bands_layout(nb)
        N = self.N
        i0 = int(pos * self.RATE) - N // 2
        lo, hi = max(0, i0), min(self.n, i0 + N)
        if hi - lo < N // 4:
            return [0.0] * nb  # before the start / past the end
        if np is not None:
            frame = np.zeros(N, dtype=np.float32)
            seg = self.x[lo:hi].astype(np.float32) / 32768.0
            frame[lo - i0: lo - i0 + len(seg)] = seg
            spec = np.abs(np.fft.rfft(frame * self.win)) / self.norm
            return [self._level(float(spec[b0:b1].max()), tilt[k], gain_db) for k, (b0, b1) in enumerate(bins)]
        # pure-Python fallback: one Goertzel filter per band
        seg = self.x[lo:hi]
        xs = [0.0] * N
        for j, v in enumerate(seg):
            xs[lo - i0 + j] = v / 32768.0 * self.win[lo - i0 + j]
        out = []
        for k, fc in enumerate(centres):
            coeff = 2.0 * math.cos(2.0 * math.pi * fc / self.RATE)
            s1 = s2 = 0.0
            for v in xs:
                s1, s2 = v + coeff * s1 - s2, s1
            power = s1 * s1 + s2 * s2 - coeff * s1 * s2
            out.append(self._level(math.sqrt(max(0.0, power)) / self.norm, tilt[k], gain_db))
        return out


def simulate_bands(t: float, nb: int) -> list:
    """Stand-in motion for tracks that could not be decoded (clearly labelled 'Simulated' in the settings)."""
    out = []
    beat = max(0.0, math.sin(t * 2 * math.pi * 2.1)) ** 3
    for i in range(nb):
        f = i / max(1, nb - 1)
        v = 0.55 + 0.45 * math.sin(t * (1.3 + i * 0.21) + i * 1.7)
        v *= 0.35 + 0.65 * (1.0 - f) ** 1.2
        out.append(max(0.0, min(1.0, 0.12 + 0.75 * v * (0.65 + 0.45 * beat * (1.0 - f)))))
    return out


def lerp_color(a: QColor, b: QColor, t: float) -> QColor:
    t = max(0.0, min(1.0, t))
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t))


def stops_color(stops: list, x: float) -> QColor:
    """Colour at position x (0..1) along evenly spaced colour stops."""
    if len(stops) == 1:
        return stops[0]
    x = max(0.0, min(1.0, x)) * (len(stops) - 1)
    i = min(int(x), len(stops) - 2)
    return lerp_color(stops[i], stops[i + 1], x - i)


def cover_palette(img: QImage, n: int = 4, vivid: bool = True) -> list:
    """A few clearly different colours from the cover (histogram of 24x24 pixels).

    vivid=True lifts saturation / brightness (for the visualizer); vivid=False keeps the real, dominant colours."""
    small = img.scaled(24, 24, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    bins: dict = {}
    for y in range(small.height()):
        for x in range(small.width()):
            c = small.pixelColor(x, y)
            b = bins.setdefault((c.red() >> 5, c.green() >> 5, c.blue() >> 5), [0, 0, 0, 0])
            b[0] += 1
            b[1] += c.red()
            b[2] += c.green()
            b[3] += c.blue()
    cands = []
    for cnt, r, g, b in bins.values():
        col = QColor(r // cnt, g // cnt, b // cnt)
        if vivid:
            cands.append((cnt * (0.25 + col.saturationF()) * (0.35 + col.valueF()), col))  # favour vivid, bright
        else:
            cands.append((float(cnt), col))  # favour whatever covers most of the picture
    cands.sort(key=lambda it: -it[0])
    picked: list = []
    for _score, col in cands:
        if all(abs(col.red() - q.red()) + abs(col.green() - q.green()) + abs(col.blue() - q.blue())
               > (140 if vivid else 90) for q in picked):
            picked.append(col)
        if len(picked) >= n:
            break
    if not vivid:
        return picked
    out = []
    for col in picked:  # keep the hue, lift saturation / brightness so it reads well on the LCD
        h = col.hueF() if col.hueF() >= 0 else 0.0
        sat = max(col.saturationF(), 0.45) if col.saturationF() > 0.08 else 0.0
        out.append(QColor.fromHsvF(h, min(1.0, sat), max(col.valueF(), 0.78)))
    if len(out) == 1:
        out.append(out[0].lighter(140))
    return out


COVER_SKINS = ("Cover Match", "Cover Vibrant", "Cover Lava")
DEFAULT_COVER_PAL = ["#c4c8ce", "#8e939b", "#e1e3e6", "#6c7075"]  # used until a song with a cover is playing


def fill_palette(pal: list, n: int = 4) -> list:
    """Exactly n colours: the given ones, topped up with hue-shifted variants of them."""
    base = [QColor(c) for c in pal] or [QColor(c) for c in DEFAULT_COVER_PAL]
    out = base[:n]
    i = 0
    while len(out) < n:
        c = base[i % len(base)]
        h = c.hueF() if c.hueF() >= 0 else 0.0
        v = c.valueF() * (0.82 if len(out) % 2 else 1.12)
        out.append(QColor.fromHsvF((h + 0.07 * len(out)) % 1.0, min(1.0, c.saturationF()), max(0.0, min(1.0, v))))
        i += 1
    return out


def approach(c: QColor, t: QColor, k: float) -> QColor:
    """Move colour c towards t by fraction k, always at least one step per channel (so it really arrives)."""
    def ch(a: int, b: int) -> int:
        d = b - a
        if d == 0:
            return a
        step = d * k
        if abs(step) < 1.0:
            step = 1.0 if d > 0 else -1.0
        return b if abs(step) >= abs(d) else int(round(a + step))

    return QColor(ch(c.red(), t.red()), ch(c.green(), t.green()), ch(c.blue(), t.blue()))


def vibrant(c: QColor) -> QColor:
    """Push a colour towards 'vivid' without changing its hue (greys stay grey)."""
    if c.saturationF() < 0.08:
        return QColor.fromHsvF(0.0, 0.0, max(c.valueF(), 0.85))
    return QColor.fromHsvF(c.hueF(), max(c.saturationF(), 0.62), max(c.valueF(), 0.9))


# name -> (how it is coloured, colour stops):  ink = LCD ink, v = by height, h = by band, cover = from the cover art
VIZ_COLORS = {
    "LCD": ("ink", []),
    "Rainbow": ("h", ["#ff3b30", "#ff9500", "#ffd60a", "#34c759", "#00c7be", "#0a84ff", "#bf5af2"]),
    "Fire": ("v", ["#c1121f", "#ff7b00", "#ffe066"]),
    "Ocean": ("v", ["#26407a", "#2f7fd6", "#5ef0ff"]),
    "Neon": ("h", ["#39ff14", "#00e5ff", "#ff2bd6"]),
    "Sunset": ("v", ["#5b3cc4", "#ef476f", "#ffd166"]),
    "Cover": ("cover", []),
}


# --------------------------------------------------------------------------- Discord Rich Presence


class _SockTransport:
    """Discord IPC over a Unix socket (Linux / macOS)."""

    def __init__(self, sock):
        self.s = sock

    def send(self, data: bytes) -> None:
        self.s.sendall(data)

    def recv(self, n: int) -> bytes:
        return self.s.recv(n)

    def close(self) -> None:
        self.s.close()


class _PipeTransport:
    """Discord IPC over a Windows named pipe, opened as an unbuffered binary file."""

    def __init__(self, f):
        self.f = f

    def send(self, data: bytes) -> None:
        view = memoryview(data)
        while len(view):
            n = self.f.write(view)
            if not n:
                raise OSError("pipe closed")
            view = view[n:]

    def recv(self, n: int) -> bytes:
        return self.f.read(n) or b""

    def close(self) -> None:
        self.f.close()


class DiscordRPC(threading.Thread):
    """Minimal Discord Rich Presence client.

    Talks straight to the local Discord IPC socket (no extra dependency). All network work happens on this
    background thread; the UI only calls configure() / post() / shutdown(), which never block.
    """

    MIN_INTERVAL = 4.0  # seconds between updates (Discord rate-limits presence changes)

    def __init__(self):
        super().__init__(daemon=True, name="discord-rpc")
        self._lock = threading.Lock()
        self._stop_evt = threading.Event()
        self._enabled = False
        self._client_id = ""
        self._activity: Optional[dict] = None
        self._dirty = False
        self._sock = None  # a _SockTransport / _PipeTransport while connected
        self._conn_id = ""
        self._last_send = 0.0
        self._next_try = 0.0
        self._why = ""
        self._rejected = False
        self.status = "Off"  # Off | No ID | No Discord | Bad ID | Connected | Rejected

    # -- called from the UI thread
    def configure(self, enabled: bool, client_id: str) -> None:
        with self._lock:
            if enabled != self._enabled or client_id != self._client_id:
                self._dirty = True
            self._enabled, self._client_id = bool(enabled), client_id

    def post(self, activity: Optional[dict]) -> None:
        with self._lock:
            self._activity = activity
            self._dirty = True

    def shutdown(self) -> None:
        self._stop_evt.set()
        if self.is_alive():
            self.join(1.5)

    # -- worker thread
    def run(self) -> None:
        while not self._stop_evt.wait(0.5):
            try:
                self._step()
            except Exception:
                self._drop()  # never let the thread die
        self._drop()  # closing the socket also clears the presence in Discord

    def _step(self) -> None:
        with self._lock:
            enabled, cid, act, dirty = self._enabled, self._client_id, self._activity, self._dirty
        now = time.monotonic()
        if not enabled:
            self._drop()
            self.status = "Off"
            return
        if not cid:
            self._drop()
            self.status = "No ID"
            return
        if self._sock is not None and self._conn_id != cid:
            self._drop()
        if self._sock is None:
            if now < self._next_try:
                return
            if not self._connect(cid):
                self.status = self._why or "No Discord"
                self._next_try = now + 15.0
                return
            dirty = True
        if dirty and now - self._last_send >= self.MIN_INTERVAL:
            if self._send_activity(act):
                self._last_send = now
                with self._lock:
                    if self._activity is act:
                        self._dirty = False
            else:
                self._drop()
                return
        self.status = "Rejected" if self._rejected else "Connected"

    @staticmethod
    def _ipc_paths():
        base = os.environ.get("XDG_RUNTIME_DIR") or os.environ.get("TMPDIR") or "/tmp"
        dirs = [base, f"{base}/app/com.discordapp.Discord", f"{base}/app/com.discordapp.DiscordCanary",
                f"{base}/snap.discord", "/tmp"]
        for d in dirs:
            for i in range(10):
                yield f"{d}/discord-ipc-{i}"

    @staticmethod
    def _open_pipe(i: int):
        return open(rf"\\.\pipe\discord-ipc-{i}", "r+b", buffering=0)

    def _candidates(self):
        """Yield a transport for every Discord IPC endpoint that can be opened."""
        if IS_WIN:
            for i in range(10):
                try:
                    f = self._open_pipe(i)
                except OSError:
                    continue
                yield _PipeTransport(f)
            return
        for path in self._ipc_paths():
            if not os.path.exists(path):
                continue
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(3.0)
            try:
                sock.connect(path)
            except OSError:
                sock.close()
                continue
            yield _SockTransport(sock)

    def _connect(self, cid: str) -> bool:
        self._why = ""
        self._rejected = False
        for transport in self._candidates():
            self._sock = transport  # (named _sock for historical reasons: it holds either transport)
            try:
                self._write(0, {"v": 1, "client_id": cid})
                if self._read().get("evt") == "READY":
                    self._conn_id = cid
                    return True
                self._why = "Bad ID"  # Discord answered, but refused this application id
            except (OSError, ValueError):
                pass
            self._drop()
        return False

    def _send_activity(self, activity: Optional[dict]) -> bool:
        if self._sock is None:
            return False
        try:
            self._write(1, {"cmd": "SET_ACTIVITY", "nonce": uuid.uuid4().hex,
                            "args": {"pid": os.getpid(), "activity": activity}})
            self._rejected = self._read().get("evt") == "ERROR"
            return True
        except (OSError, ValueError):
            return False

    def _write(self, op: int, payload: dict) -> None:
        data = json.dumps(payload).encode("utf-8")
        self._sock.send(struct.pack("<II", op, len(data)) + data)

    def _recvn(self, n: int) -> bytes:
        buf = b""
        while len(buf) < n:
            chunk = self._sock.recv(n - len(buf))
            if not chunk:
                raise OSError("connection closed")
            buf += chunk
        return buf

    def _read(self) -> dict:
        _op, length = struct.unpack("<II", self._recvn(8))
        body = self._recvn(length) if length else b"{}"
        return json.loads(body.decode("utf-8", "replace") or "{}")

    def _drop(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
        self._sock = None
        self._conn_id = ""


# --------------------------------------------------------------------------- the widget


class IPod(QWidget):
    # logical (unscaled) geometry, loosely matching the reference picture
    W, H, M = 370, 620, 14  # body size and transparent margin (room for the drop shadow)
    CX, CY = 185, 429  # wheel centre
    R_OUT, R_DISC, R_BTN = 156, 119, 42
    BEZEL = QRectF(58, 30, 257, 214)
    LCD = QRectF(66, 38, 241, 198)
    HDR, ROW, VIS = 28, 21, 8
    STEP_DEG = 14.0  # degrees of wheel rotation per "click"
    SIZES = (0.75, 1.0, 1.25, 1.5)
    CLICK_LEVELS = (0, 25, 50, 85, 100)  # percent

    def __init__(self, cfg: dict, font_family: str):
        super().__init__()
        self.cfg = cfg
        self.scale_f = float(cfg.get("scale", 1.0))

        self.rpc = DiscordRPC()
        self.rpc.start()
        self._rpc_timer = QTimer(self, singleShot=True, interval=400)  # coalesces bursts of events
        self._rpc_timer.timeout.connect(self.discord_sync)

        flags = Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint
        if cfg.get("always_on_top"):
            flags |= Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setWindowTitle(APP_NAME)
        self._apply_size()
        apply_lcd(cfg.get("lcd", "Classic"))
        self.setWindowOpacity(max(0.3, min(1.0, float(cfg.get("opacity", 1.0)))))

        self.f_main = QFont(font_family)
        self.f_main.setPixelSize(14)
        self.f_main.setBold(True)
        self.f_small = QFont(font_family)
        self.f_small.setPixelSize(12)
        self.f_small.setBold(True)
        self.f_label = QFont("Sans Serif")
        self.f_label.setPixelSize(13)

        # audio ---------------------------------------------------------------
        self.audio = QAudioOutput()
        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio)
        self.set_volume(float(cfg.get("volume", 0.6)), overlay=False)
        self.player.mediaStatusChanged.connect(self._on_status)
        self.player.positionChanged.connect(self._on_position)
        self.player.playbackStateChanged.connect(self._on_state)
        self.player.errorOccurred.connect(self._on_error)

        self.click_fx: Optional[Sfx] = None
        self.thud_fx: Optional[Sfx] = None
        try:
            d = sfx_dir()
            make_click_wav(d / "click.wav")
            make_thud_wav(d / "thud.wav")
            self.click_fx = Sfx(d / "click.wav")
            self.thud_fx = Sfx(d / "thud.wav")
        except Exception as exc:  # no writable folder / no audio: the player itself still works
            print(f"pyPod: could not set up UI sounds: {exc}", file=sys.stderr)

        # state ---------------------------------------------------------------
        self.library: list[Track] = []
        self.scan_count: Optional[int] = None
        self.scanner: Optional[Scanner] = None
        self.queue: list[Track] = []
        self.order: list[int] = []
        self.opos = -1
        self.err_streak = 0
        self.scrub = False
        self.vol_until = 0.0
        self.marquee_t0 = time.monotonic()
        self._anim = False
        self.cover: Optional[QImage] = None
        self.art_cache: dict = {}
        self.track_t0 = time.monotonic()
        self.disc_t0 = time.monotonic()
        self.disc_angle = 0.0
        self.disc_speed = 0.0
        self.disc_t = 9.0
        self.analysis: Optional[AudioAnalysis] = None
        self.viz_src = "-"  # - | Loading | Live | Simulated
        self._viz_token = 0
        self._viz_last = time.monotonic()
        self.viz_levels: list = []
        self.viz_peaks: list = []
        self.viz_hold: list = []
        self.cover_pal: list = []
        self.skin_true = fill_palette([])  # colours of the current cover, as they are
        self.skin_vivid = fill_palette([])  # the same, lifted
        self.skin_true_cur = [QColor(c) for c in self.skin_true]  # what is on screen (fades between songs)
        self.skin_vivid_cur = [QColor(c) for c in self.skin_vivid]
        self._skin_last = time.monotonic()
        self._pos_ms = 0
        self._pos_t = time.monotonic()
        self._disc_last = time.monotonic()
        self.pressed: Optional[str] = None
        self.last_ang = 0.0
        self.acc = 0.0
        self.wheel_acc = 0
        self.hold_fired = False
        self._drag_off: Optional[QPointF] = None

        self.hold_timer = QTimer(self, singleShot=True, interval=450)
        self.hold_timer.timeout.connect(self._hold_fire)
        self.seek_timer = QTimer(self, interval=100)
        self.seek_timer.timeout.connect(self._seek_tick)
        self.ticker = QTimer(self, interval=40)
        self.ticker.timeout.connect(self._tick)
        self.ticker.start()

        self.stack: list[Screen] = [self._root_screen()]

        pos = cfg.get("pos")
        if isinstance(pos, list) and len(pos) == 2:
            pt = QPoint(int(pos[0]), int(pos[1]))
            if any(s.geometry().contains(pt) for s in QGuiApplication.screens()):
                self.move(pt)

        self.discord_sync()

        if cfg.get("folder") and Path(cfg["folder"]).is_dir():
            self.start_scan()
        else:
            QTimer.singleShot(400, self.choose_folder)

    # ------------------------------------------------------------------ geometry / window

    def _apply_size(self):
        s = self.scale_f
        self.setFixedSize(round((self.W + 2 * self.M) * s), round((self.H + 2 * self.M) * s))

    def set_scale(self, s: float):
        self.scale_f = s
        self.cfg["scale"] = s
        self._apply_size()
        self.update()
        save_config(self.cfg)

    def _map(self, pos) -> QPointF:
        s = self.scale_f
        return QPointF(pos.x() / s - self.M, pos.y() / s - self.M)

    def set_always_on_top(self, on: bool):
        on = bool(on)
        pos = self.pos()
        self.cfg["always_on_top"] = on
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, on)
        self.show()
        self.move(pos)
        self.raise_()
        self.activateWindow()
        save_config(self.cfg)
        self.update()

    def save_state(self):
        self.cfg["pos"] = [self.x(), self.y()]
        save_config(self.cfg)

    def closeEvent(self, e):
        self.save_state()
        self.player.stop()
        self.rpc.shutdown()
        super().closeEvent(e)

    # ------------------------------------------------------------------ library

    def choose_folder(self):
        start = self.cfg.get("folder") or str(Path.home() / "Music")
        if not Path(start).is_dir():
            start = str(Path.home())
        d = QFileDialog.getExistingDirectory(self, "Select your music folder", start)
        if d:
            self.cfg["folder"] = os.path.normpath(d)  # Qt returns forward slashes on Windows
            save_config(self.cfg)
            self.start_scan()

    def start_scan(self):
        folder = self.cfg.get("folder", "")
        if not folder or not Path(folder).is_dir() or (self.scanner and self.scanner.isRunning()):
            return
        self.scan_count = 0
        self.scanner = Scanner(folder)
        self.scanner.progress.connect(self._scan_progress)
        self.scanner.done.connect(self._scan_done)
        self.scanner.start()
        self.update()

    def _scan_progress(self, n: int):
        self.scan_count = n
        self.update()

    def _scan_done(self, tracks: list):
        self.library = tracks
        self.scan_count = None
        for scr in self.stack:
            scr.refresh()
        self.update()

    # ------------------------------------------------------------------ menus

    def _root_screen(self) -> Screen:
        def build():
            items = [
                Item("Music", self.open_music, arrow=True),
                Item("Now Playing", self.open_now, arrow=True),
                Item("Shuffle Songs", self.shuffle_all),
            ]
            if self.cfg["viz"]:
                items.append(Item("Visualizer", self.open_viz, arrow=True))
            items.append(Item("Settings", self.open_settings, arrow=True))
            return items

        return Screen(APP_NAME, builder=build)

    def push(self, scr: Screen):
        self.stack.append(scr)
        self.marquee_t0 = time.monotonic()
        self.update()

    def open_music(self):
        def build():
            if not self.library:
                msg = "Scanning..." if self.scan_count is not None else "Choose Folder..."
                return [Item(msg, None if self.scan_count is not None else self.choose_folder)]
            root = self.cfg.get("folder", "")
            return [
                Item("Folders", lambda: self.push(Screen(
                    Path(root).name or "Folders", builder=lambda: self.folder_items(root))), arrow=True),
                Item("Songs", lambda: self.push(Screen("Songs", builder=lambda: self.song_items(
                    sorted(self.library, key=lambda t: t.title.lower())))), arrow=True),
                Item("Artists", lambda: self.push(Screen("Artists", builder=self.artist_items)), arrow=True),
                Item("Albums", lambda: self.push(Screen("Albums", builder=self.album_items)), arrow=True),
                Item("Change Music Folder...", self.choose_folder),
            ]

        self.push(Screen("Music", builder=build))

    def folder_items(self, d: str) -> list[Item]:
        """Contents of one directory: 'Play All', sub-folders (that hold music), then the songs inside it."""
        d = os.path.normpath(d)
        prefix = d if d.endswith(os.sep) else d + os.sep  # (a drive / filesystem root already ends with one)
        direct: list[Track] = []
        subs: set[str] = set()
        below: list[Track] = []
        for t in self.library:
            if not t.path.startswith(prefix):
                continue
            below.append(t)
            parts = t.path[len(prefix):].split(os.sep)
            if len(parts) == 1:
                direct.append(t)
            else:
                subs.add(parts[0])
        key = lambda t: (t.number, t.path.lower())  # noqa: E731
        items: list[Item] = []
        if below and (subs or len(direct) > 1):
            allt = sorted(below, key=lambda t: t.path.lower())
            items.append(Item("Play All", lambda tr=allt: self.play_from(tr, 0)))
        for name in sorted(subs, key=str.lower):
            sub = os.path.join(d, name)
            items.append(Item(name, lambda sub=sub, name=name: self.push(
                Screen(name, builder=lambda: self.folder_items(sub))), arrow=True))
        items += self.song_items(sorted(direct, key=key))
        return items

    def song_items(self, tracks: list[Track]) -> list[Item]:
        return [Item(t.title, lambda tr=tracks, i=i: self.play_from(tr, i)) for i, t in enumerate(tracks)]

    def artist_items(self) -> list[Item]:
        names = sorted({t.artist for t in self.library}, key=str.lower)

        def songs(n):
            return sorted((t for t in self.library if t.artist == n),
                          key=lambda t: (t.album.lower(), t.number, t.title.lower()))

        return [Item(n, lambda n=n: self.push(Screen(n, builder=lambda: self.song_items(songs(n)))), arrow=True)
                for n in names]

    def album_items(self) -> list[Item]:
        names = sorted({t.album for t in self.library}, key=str.lower)

        def songs(n):
            return sorted((t for t in self.library if t.album == n), key=lambda t: (t.number, t.title.lower()))

        return [Item(n, lambda n=n: self.push(Screen(n, builder=lambda: self.song_items(songs(n)))), arrow=True)
                for n in names]

    def open_now(self):
        if self.stack[-1].kind != "now":
            self.disc_t0 = time.monotonic()
            self.push(Screen("Now Playing", kind="now"))

    def open_settings(self):
        onoff = lambda k: (lambda: "On" if self.cfg[k] else "Off")  # noqa: E731
        self.push(Screen("Settings", [
            Item("Appearance", self.open_appearance, arrow=True),
            Item("Discord", self.open_discord, arrow=True, value=lambda: "On" if self.cfg["discord"] else "Off"),
            Item("Visualizer", self.open_viz_settings, arrow=True, value=lambda: "On" if self.cfg["viz"] else "Off"),
            Item("Always on Top", lambda: self.set_always_on_top(not self.cfg["always_on_top"]), value=onoff("always_on_top")),
            Item("Repeat", self.cycle_repeat, value=lambda: self.cfg["repeat"].capitalize()),
            Item("Shuffle", self.toggle_shuffle, value=onoff("shuffle")),
            Item("Clicker Volume", self.cycle_click_volume, value=lambda: f"{self.click_pct()}%"),
            Item("Click Engine", self.cycle_engine, value=lambda: self.cfg["click_engine"]),
            Item("Sensitivity", lambda: self.cycle_cfg("sensitivity", ["low", "normal", "high"]),
                 value=lambda: self.cfg["sensitivity"].capitalize()),
            Item("Size", self.cycle_size, value=lambda: f"{round(self.scale_f * 100)}%"),
            Item("Music Folder...", self.choose_folder),
            Item("Rescan Library", self.start_scan),
            Item("Quit", self.close),
        ]))

    def open_appearance(self):
        cur = lambda: "Rainbow" if self.cfg["rainbow"] else self.cfg["skin"]  # noqa: E731
        self.push(Screen("Appearance", [
            Item("Skin", self.open_skins, arrow=True, value=cur),
            Item("Rainbow Mode", self.toggle_rainbow, value=lambda: "On" if self.cfg["rainbow"] else "Off"),
            Item("Rainbow Speed", lambda: self.cycle_cfg("rainbow_speed", ["slow", "medium", "fast"]),
                 value=lambda: self.cfg["rainbow_speed"].capitalize()),
            Item("Wheel", lambda: self.cycle_cfg("wheel_style", ["match", "white", "black"]),
                 value=lambda: self.cfg["wheel_style"].capitalize()),
            Item("Screen", self.cycle_lcd, value=lambda: self.cfg["lcd"]),
            Item("Opacity", self.cycle_opacity, value=lambda: f"{round(self.cfg['opacity'] * 100)}%"),
            Item("Shadow", lambda: self.cycle_cfg("shadow", [True, False]),
                 value=lambda: "On" if self.cfg["shadow"] else "Off"),
            Item("Album Art", lambda: self.cycle_cfg("art", ["Color", "LCD", "Off"]),
                 value=lambda: self.cfg["art"]),
            Item("Mini Ticker", lambda: self.cycle_cfg("ticker", [True, False]),
                 value=lambda: "On" if self.cfg["ticker"] else "Off"),
            Item("Slam Shake", lambda: self.cycle_cfg("shake", [True, False]),
                 value=lambda: "On" if self.cfg["shake"] else "Off"),
        ]))

    def open_skins(self):
        mark = lambda n: (lambda: "*" if (not self.cfg["rainbow"] and self.cfg["skin"] == n) else "")  # noqa: E731
        items = [Item(n, lambda n=n: self.set_skin(n), value=mark(n)) for n in (*COVER_SKINS, *SKINS)]
        items.append(Item("Custom...", self.pick_custom_color, value=mark("Custom")))
        scr = Screen("Skin", items)
        names = [*COVER_SKINS, *SKINS, "Custom"]
        if self.cfg["skin"] in names:
            scr.sel = names.index(self.cfg["skin"])
            scr.top = max(0, min(scr.sel - 3, len(items) - self.VIS))
        self.push(scr)

    def cycle_repeat(self):
        modes = ["off", "all", "one"]
        self.cfg["repeat"] = modes[(modes.index(self.cfg["repeat"]) + 1) % 3]
        save_config(self.cfg)
        self.update()

    def toggle_shuffle(self):
        self.cfg["shuffle"] = not self.cfg["shuffle"]
        save_config(self.cfg)
        if self.order and 0 <= self.opos < len(self.order):
            self._build_order(self.order[self.opos], self.cfg["shuffle"])
        self.update()

    def cycle_engine(self):
        self.cycle_cfg("click_engine", ["Auto", "Qt", "System"])
        self.click()  # audible test of the engine you just picked

    def click_pct(self) -> int:
        try:
            return max(0, min(100, int(self.cfg["click_volume"])))
        except (TypeError, ValueError, KeyError):
            return 50

    def cycle_click_volume(self):
        cur = self.click_pct()
        lv = self.CLICK_LEVELS
        i = min(range(len(lv)), key=lambda k: abs(lv[k] - cur))
        self.cfg["click_volume"] = lv[(i + 1) % len(lv)]
        save_config(self.cfg)
        self.click()  # audible test at the new level (silent at 0%)
        self.update()

    def cycle_size(self):
        i = min(range(len(self.SIZES)), key=lambda k: abs(self.SIZES[k] - self.scale_f))
        self.set_scale(self.SIZES[(i + 1) % len(self.SIZES)])

    # ------------------------------------------------------------------ playback

    @property
    def current(self) -> Optional[Track]:
        if 0 <= self.opos < len(self.order):
            return self.queue[self.order[self.opos]]
        return None

    def is_playing(self) -> bool:
        return self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    def _build_order(self, start: int, shuffle: bool):
        idx = list(range(len(self.queue)))
        if shuffle:
            random.shuffle(idx)
            if start in idx:
                idx.remove(start)
                idx.insert(0, start)
            self.order, self.opos = idx, 0
        else:
            self.order, self.opos = idx, start

    def play_from(self, tracks: list[Track], start: int = 0, shuffle: Optional[bool] = None):
        if not tracks:
            return
        self.queue = list(tracks)
        self._build_order(start, self.cfg["shuffle"] if shuffle is None else shuffle)
        self.err_streak = 0
        self._load()
        self.open_now()

    def shuffle_all(self):
        if not self.library:
            self.choose_folder()
            return
        self.play_from(self.library, random.randrange(len(self.library)), shuffle=True)

    def _load(self):
        t = self.current
        if not t:
            return
        self.scrub = False
        self.marquee_t0 = self.track_t0 = self.disc_t0 = time.monotonic()
        self.set_cover(t)
        if self.cfg["viz"]:
            self.viz_load(t.path)
        self.player.setSource(QUrl.fromLocalFile(t.path))
        self.player.play()
        self.rpc_soon()
        self.update()

    def toggle_play(self):
        if self.current is None:
            if self.library:
                self.play_from(sorted(self.library, key=lambda t: t.title.lower()), 0)
            return
        if self.is_playing():
            self.player.pause()
        elif self.player.playbackState() == QMediaPlayer.PlaybackState.StoppedState and \
                self.player.mediaStatus() == QMediaPlayer.MediaStatus.EndOfMedia:
            self._load()
        else:
            self.player.play()

    def next_track(self, auto: bool = False):
        if not self.order:
            return
        if auto and self.cfg["repeat"] == "one":
            self.player.setPosition(0)
            self.player.play()
            return
        n = self.opos + 1
        if n >= len(self.order):
            if auto and self.cfg["repeat"] != "all":
                self.player.stop()
                self.update()
                return
            n = 0
        self.opos = n
        self._load()

    def prev_track(self):
        if not self.order:
            return
        if self.player.position() > 3000:
            self.player.setPosition(0)
            self.rpc_soon()
            return
        self.opos = (self.opos - 1) % len(self.order)
        self._load()

    def _duration(self) -> int:
        d = self.player.duration()
        if d <= 0 and self.current:
            d = int(self.current.length * 1000)
        return d

    def seek(self, delta_ms: int):
        dur = self._duration()
        if dur <= 0:
            return
        self.player.setPosition(int(max(0, min(dur - 300, self.player.position() + delta_ms))))
        self.rpc_soon()
        self.update()

    def set_volume(self, v: float, overlay: bool = True):
        v = max(0.0, min(1.0, v))
        self.cfg["volume"] = v
        self.audio.setVolume(v * v)  # squared: closer to perceived loudness
        if overlay:
            self.vol_until = time.monotonic() + 1.6
        self.update()

    # player signals
    def _on_status(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.next_track(auto=True)
        self.update()

    def _on_position(self, pos):
        self._pos_ms = pos
        self._pos_t = time.monotonic()
        if self.stack[-1].kind in ("now", "viz"):
            self.update()

    def _on_state(self, state):
        if state == QMediaPlayer.PlaybackState.PlayingState:
            self.err_streak = 0
        self.rpc_soon()
        self.update()

    def _on_error(self, _err, _msg=""):
        self.err_streak += 1
        if self.err_streak <= len(self.queue):
            self.next_track(auto=True)
        else:
            self.player.stop()

    # ------------------------------------------------------------------ input actions

    def click(self):
        pct = self.click_pct()
        if pct > 0 and self.click_fx is not None:
            self.click_fx.play(self.cfg["click_engine"], (pct / 100.0) ** 2)

    def scroll(self, steps: int):
        scr = self.stack[-1]
        if scr.kind == "menu":
            n = len(scr.items)
            if not n:
                return
            new = max(0, min(n - 1, scr.sel + steps))
            if new == scr.sel:
                return
            scr.sel = new
            if scr.sel < scr.top:
                scr.top = scr.sel
            elif scr.sel >= scr.top + self.vis():
                scr.top = scr.sel - self.vis() + 1
            self.marquee_t0 = time.monotonic()
        elif self.scrub and self.current and scr.kind == "now":
            self.seek(steps * 5000)
        else:
            self.set_volume(self.cfg["volume"] + steps * 0.03)
        self.click()
        self.update()

    def select(self):
        scr = self.stack[-1]
        if scr.kind == "menu":
            if scr.items and scr.items[scr.sel].action:
                self.click()
                scr.items[scr.sel].action()
        elif scr.kind == "viz":  # centre button: next visualizer style
            self.cycle_cfg("viz_style", ["Bars", "Mirror", "Wave", "LED"])
            self.click()
        elif self.current:
            self.scrub = not self.scrub
            self.click()
        self.update()

    def menu_button(self):
        self.click()
        if self.scrub:
            self.scrub = False
        elif len(self.stack) > 1:
            self.stack.pop()
            self.marquee_t0 = time.monotonic()
        self.update()

    def _button_action(self, name: str):
        if name == "menu":
            self.menu_button()
        elif name == "prev":
            self.prev_track()
        elif name == "next":
            self.next_track()
        elif name == "play":
            self.toggle_play()
        elif name == "center":
            self.select()

    # hold-to-seek on prev/next
    def _hold_fire(self):
        if self.pressed in ("prev", "next") and self.current:
            self.hold_fired = True
            self.seek_timer.start()

    def _seek_tick(self):
        self.seek(3000 if self.pressed == "next" else -3000)

    def _tick(self):
        now = time.monotonic()
        need = self._anim or bool(self.cfg["rainbow"]) or self.stack[-1].title == "Discord"
        if self.vol_until:
            need = True
            if now > self.vol_until:
                self.vol_until = 0.0
        if need:
            self.update()

    # ------------------------------------------------------------------ mouse / keyboard

    def hit_test(self, p: QPointF) -> Optional[str]:
        dx, dy = p.x() - self.CX, p.y() - self.CY
        r = math.hypot(dx, dy)
        if r > self.R_OUT:
            return None
        if r <= self.R_BTN:
            return "center"
        if r <= self.R_DISC:
            return "wheel"
        a = math.degrees(math.atan2(-dy, dx))
        if 45 <= a < 135:
            return "menu"
        if -45 <= a < 45:
            return "next"
        if -135 <= a < -45:
            return "play"
        return "prev"

    def _angle(self, p: QPointF) -> float:
        return math.degrees(math.atan2(p.y() - self.CY, p.x() - self.CX))  # clockwise positive

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton:
            return
        p = self._map(e.position())
        hit = self.hit_test(p)
        if hit is None:  # casing / screen: drag the whole widget
            h = self.windowHandle()
            if h is not None and h.startSystemMove():
                return
            self._drag_off = e.globalPosition() - QPointF(self.frameGeometry().topLeft())
            return
        self.pressed = hit
        if hit == "wheel":
            self.last_ang, self.acc = self._angle(p), 0.0
        else:
            self.click()
            self.hold_fired = False
            if hit in ("prev", "next"):
                self.hold_timer.start()
        self.update()

    def mouseMoveEvent(self, e):
        if self._drag_off is not None:
            self.move((e.globalPosition() - self._drag_off).toPoint())
            return
        if self.pressed == "wheel":
            p = self._map(e.position())
            if math.hypot(p.x() - self.CX, p.y() - self.CY) < 12:
                return
            a = self._angle(p)
            d = (a - self.last_ang + 180.0) % 360.0 - 180.0  # shortest signed delta
            self.last_ang = a
            self.acc += d
            sd = self.step_deg()
            while abs(self.acc) >= sd:
                step = 1 if self.acc > 0 else -1
                self.acc -= step * sd
                self.scroll(step)

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton:
            return
        if self._drag_off is not None:
            self._drag_off = None
            self.save_state()
            return
        pressed, self.pressed = self.pressed, None
        self.hold_timer.stop()
        self.seek_timer.stop()
        if pressed and pressed != "wheel":
            hit = self.hit_test(self._map(e.position()))
            if hit == pressed and not self.hold_fired:
                self._button_action(pressed)
        self.hold_fired = False
        self.update()

    def wheelEvent(self, e):
        self.wheel_acc += e.angleDelta().y()
        while abs(self.wheel_acc) >= 120:
            step = -1 if self.wheel_acc > 0 else 1  # wheel down == clockwise == down
            self.wheel_acc -= -step * 120
            self.scroll(step)

    def keyPressEvent(self, e):
        k = e.key()
        K = Qt.Key
        if k == K.Key_Up:
            self.scroll(-1)
        elif k == K.Key_Down:
            self.scroll(1)
        elif k in (K.Key_Return, K.Key_Enter):
            self.select()
        elif k in (K.Key_Escape, K.Key_Backspace, K.Key_M):
            self.menu_button()
        elif k == K.Key_Space:
            self.toggle_play()
        elif k == K.Key_Left:
            self.prev_track()
        elif k == K.Key_Right:
            self.next_track()
        elif k in (K.Key_Plus, K.Key_Equal):
            self.set_volume(self.cfg["volume"] + 0.05)
        elif k == K.Key_Minus:
            self.set_volume(self.cfg["volume"] - 0.05)
        else:
            super().keyPressEvent(e)

    def contextMenuEvent(self, e):
        m = QMenu(self)
        a = m.addAction("Always on Top")
        a.setCheckable(True)
        a.setChecked(bool(self.cfg["always_on_top"]))
        a.triggered.connect(self.set_always_on_top)
        sz = m.addMenu("Size")
        for s in self.SIZES:
            act = sz.addAction(f"{round(s * 100)}%")
            act.setCheckable(True)
            act.setChecked(abs(s - self.scale_f) < 0.01)
            act.triggered.connect(lambda _=False, s=s: self.set_scale(s))
        sk = m.addMenu("Skin")
        for n in COVER_SKINS:
            sk.addAction(n).triggered.connect(lambda _=False, n=n: self.set_skin(n))
        sk.addSeparator()
        for n in SKINS:
            sk.addAction(n).triggered.connect(lambda _=False, n=n: self.set_skin(n))
        sk.addAction("Custom Color...").triggered.connect(self.pick_custom_color)
        r = m.addAction("Rainbow Mode")
        r.setCheckable(True)
        r.setChecked(bool(self.cfg["rainbow"]))
        r.triggered.connect(self.toggle_rainbow)
        m.addAction("Choose Music Folder...", self.choose_folder)
        m.addAction("Rescan Library", self.start_scan)
        m.addSeparator()
        m.addAction("Quit", self.close)
        m.exec(e.globalPos())

    # ------------------------------------------------------------------ cover art

    def vis(self) -> int:
        """Visible menu rows (one fewer while the now-playing ticker strip is shown)."""
        return self.VIS - 1 if self.ticker_on() else self.VIS

    def ticker_on(self) -> bool:
        return bool(self.cfg["ticker"]) and self.current is not None and self.stack[-1].kind == "menu"

    def set_cover(self, t: Track):
        self.art_cache.clear()
        self.cover = None
        self.cover_pal = []
        data = load_cover(t.path)
        if data:
            img = QImage()
            if img.loadFromData(data) and not img.isNull():
                side = min(img.width(), img.height())  # centre-crop to a square
                self.cover = img.copy((img.width() - side) // 2, (img.height() - side) // 2, side, side)
                self.cover_pal = cover_palette(self.cover)
                chroma = [c for c in self.cover_pal if c.saturationF() >= 0.25]  # skip white / grey for the lively skins
                self.skin_vivid = fill_palette(chroma if len(chroma) >= 2 else self.cover_pal)
                self.skin_true = fill_palette(cover_palette(self.cover, vivid=False))
        self.update()

    def art(self, size: int) -> Optional[QImage]:
        """Cover scaled to size x size px, tinted to the LCD colours when Album Art is 'LCD'."""
        mode = self.cfg["art"]
        if self.cover is None or mode == "Off":
            return None
        key = (size, mode, self.cfg["lcd"])
        img = self.art_cache.get(key)
        if img is None:
            img = self.cover.scaled(size, size, Qt.AspectRatioMode.IgnoreAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation)
            if mode == "LCD":
                img = self._tint(img)
            self.art_cache[key] = img
        return img

    @staticmethod
    def _tint(img: QImage) -> QImage:
        g = img.convertToFormat(QImage.Format.Format_Grayscale8)
        out = QImage(g.size(), QImage.Format.Format_ARGB32)
        dark, light = (INK, LCD_HI) if INK.lightnessF() < LCD_HI.lightnessF() else (LCD_HI, INK)
        dr, dg, db = dark.red(), dark.green(), dark.blue()
        lr, lg, lb = light.red() - dr, light.green() - dg, light.blue() - db
        for y in range(g.height()):
            for x in range(g.width()):
                t = (g.pixel(x, y) & 0xFF) / 255.0
                t = max(0.0, min(1.0, (t - 0.5) * 1.25 + 0.5))
                out.setPixelColor(x, y, QColor(int(dr + lr * t), int(dg + lg * t), int(db + lb * t)))
        return out

    # ------------------------------------------------------------------ visualizer

    def open_viz(self):
        if self.stack[-1].kind != "viz":
            self.push(Screen("Visualizer", kind="viz"))

    def open_viz_settings(self):
        onoff = lambda k: (lambda: "On" if self.cfg[k] else "Off")  # noqa: E731
        self.push(Screen("Visualizer", [
            Item("Visualizer", self.toggle_viz, value=onoff("viz")),
            Item("Style", lambda: self.cycle_cfg("viz_style", ["Bars", "Mirror", "Wave", "LED"]),
                 value=lambda: self.cfg["viz_style"]),
            Item("Colors", lambda: self.cycle_cfg("viz_colors", list(VIZ_COLORS)), value=lambda: self.cfg["viz_colors"]),
            Item("Bars", lambda: self.cycle_cfg("viz_bars", [16, 24, 32]), value=lambda: str(self.cfg["viz_bars"])),
            Item("Gain", lambda: self.cycle_cfg("viz_gain", ["Low", "Normal", "High"]), value=lambda: self.cfg["viz_gain"]),
            Item("Peaks", lambda: self.cycle_cfg("viz_peaks", [True, False]), value=onoff("viz_peaks")),
            Item("Smoothing", lambda: self.cycle_cfg("viz_smooth", ["Snappy", "Normal", "Smooth"]),
                 value=lambda: self.cfg["viz_smooth"]),
            Item("Source", None, value=lambda: self.viz_src if self.cfg["viz"] else "Off"),
        ]))

    def toggle_viz(self):
        self.cfg["viz"] = not self.cfg["viz"]
        save_config(self.cfg)
        self.stack[0].refresh()  # adds / removes the main-menu entry
        if self.cfg["viz"] and self.current is not None:
            self.viz_load(self.current.path)
        else:
            self._viz_token += 1
            self.analysis, self.viz_src = None, "-"
        self.update()

    def viz_load(self, path: str):
        """Decode the track in the background; the spectrum is then looked up by playback position."""
        self._viz_token += 1
        token = self._viz_token
        self.analysis, self.viz_src = None, "Loading"

        def work():
            smp = decode_mono(path)
            if token != self._viz_token:
                return  # the track changed meanwhile
            self.analysis = AudioAnalysis(smp) if smp is not None else None
            self.viz_src = "Live" if self.analysis is not None else "Simulated"

        threading.Thread(target=work, daemon=True, name="viz-decode").start()

    def _advance_viz(self):
        """Once per paint: fetch the spectrum for the current position and apply attack / fall / peak-hold."""
        now = time.monotonic()
        dt = min(0.2, now - self._viz_last)
        self._viz_last = now
        nb = int(self.cfg["viz_bars"])
        if len(self.viz_levels) != nb:
            self.viz_levels, self.viz_peaks, self.viz_hold = [0.0] * nb, [0.0] * nb, [0.0] * nb
        if not (self.cfg["viz"] and self.stack[-1].kind in ("now", "viz")):
            return
        playing = self.is_playing()
        raw = [0.0] * nb
        if playing:
            if self.analysis is not None:
                pos = (self._pos_ms + (now - self._pos_t) * 1000.0) / 1000.0
                gain = {"Low": -8.0, "Normal": 0.0, "High": 8.0}.get(self.cfg["viz_gain"], 0.0)
                raw = self.analysis.bands(pos + 0.02, nb, gain)
            elif self.viz_src == "Simulated":
                raw = simulate_bands(now, nb)
        fall = {"Snappy": 4.0, "Normal": 2.2, "Smooth": 1.2}.get(self.cfg["viz_smooth"], 2.2)
        lv, pk, hold = self.viz_levels, self.viz_peaks, self.viz_hold
        for i in range(nb):
            r, cur = raw[i], lv[i]
            cur = cur + (r - cur) * min(1.0, dt * 24.0) if r > cur else max(r, cur - dt * fall)
            lv[i] = cur
            if cur >= pk[i]:
                pk[i], hold[i] = cur, now + 0.4
            elif now > hold[i]:
                pk[i] = max(cur, pk[i] - dt * 0.9)
        if playing or max(lv) > 0.01 or max(pk) > 0.01:
            self._anim = True  # keep repainting while anything moves

    def viz_color(self, i: int, n: int, t: float) -> QColor:
        """Colour of band i of n at height t (0 = base of the bar, 1 = tip)."""
        mode, stops = VIZ_COLORS.get(self.cfg["viz_colors"], VIZ_COLORS["LCD"])
        if mode == "cover":
            if len(self.cover_pal) >= 2:  # blend the cover's colours across the bands
                base = stops_color(self.cover_pal, i / max(1, n - 1))
                return lerp_color(base.darker(135), base.lighter(125), t)
            mode, stops = VIZ_COLORS["Rainbow"]  # no cover (disc placeholder): fall back
        if mode == "ink":
            return INK
        cols = [QColor(c) for c in stops]
        if mode == "v":
            return stops_color(cols, t)
        base = stops_color(cols, i / max(1, n - 1))
        return lerp_color(base.darker(125), base.lighter(115), t)

    def draw_viz(self, p: QPainter, r: QRectF):
        lv, pk = self.viz_levels, self.viz_peaks
        n = len(lv)
        if n < 2 or r.height() < 6:
            return
        style = self.cfg["viz_style"]
        peaks = bool(self.cfg["viz_peaks"])
        p.save()
        p.setClipRect(r.adjusted(-1, -1, 1, 1))
        p.setPen(Qt.PenStyle.NoPen)
        if style == "Wave":
            pts = [QPointF(r.left() + i * r.width() / (n - 1), r.bottom() - lv[i] * r.height()) for i in range(n)]
            path = QPainterPath(QPointF(r.left(), r.bottom()))
            path.lineTo(pts[0])
            for a, b in zip(pts, pts[1:]):
                path.quadTo(a, QPointF((a.x() + b.x()) / 2, (a.y() + b.y()) / 2))
            path.lineTo(pts[-1])
            path.lineTo(QPointF(r.right(), r.bottom()))
            path.closeSubpath()
            g = QLinearGradient(r.left(), 0, r.right(), 0)
            for i in range(n):
                g.setColorAt(i / (n - 1), self.viz_color(i, n, 0.6))
            p.setOpacity(0.55)
            p.fillPath(path, QBrush(g))
            p.setOpacity(1.0)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QBrush(g), 1.6))
            p.drawPath(path)
        else:
            gap = 2.0 if r.width() / n > 5.5 else 1.0
            bw = (r.width() - gap * (n - 1)) / n
            for i in range(n):
                x = r.left() + i * (bw + gap)
                if style == "LED":
                    seg, sgap = 4.0, 2.0
                    count = max(2, int((r.height() + sgap) / (seg + sgap)))
                    lit = int(lv[i] * count + 0.5)
                    for k in range(lit):
                        p.setBrush(self.viz_color(i, n, k / (count - 1)))
                        p.drawRect(QRectF(x, r.bottom() - (k + 1) * (seg + sgap) + sgap, bw, seg))
                    if peaks and pk[i] > 0.02:
                        k = min(count - 1, int(pk[i] * count))
                        p.setBrush(self.viz_color(i, n, 1.0))
                        p.drawRect(QRectF(x, r.bottom() - (k + 1) * (seg + sgap) + sgap, bw, seg))
                    continue
                if style == "Mirror":
                    cy, half = r.center().y(), r.height() / 2.0
                    h = max(0.8, lv[i] * half)
                    g = QLinearGradient(0, cy, 0, r.top())
                    g.setSpread(QGradient.Spread.ReflectSpread)
                    g.setColorAt(0.0, self.viz_color(i, n, 0.0))
                    g.setColorAt(0.5, self.viz_color(i, n, 0.5))
                    g.setColorAt(1.0, self.viz_color(i, n, 1.0))
                    p.setBrush(QBrush(g))
                    p.drawRect(QRectF(x, cy - h, bw, 2 * h))
                    if peaks and pk[i] > 0.02:
                        p.setBrush(self.viz_color(i, n, 1.0))
                        ph = pk[i] * half
                        p.drawRect(QRectF(x, cy - ph - 1.8, bw, 1.6))
                        p.drawRect(QRectF(x, cy + ph + 0.2, bw, 1.6))
                    continue
                h = max(1.0, lv[i] * r.height())  # Bars
                g = QLinearGradient(0, r.bottom(), 0, r.top())
                g.setColorAt(0.0, self.viz_color(i, n, 0.0))
                g.setColorAt(0.5, self.viz_color(i, n, 0.5))
                g.setColorAt(1.0, self.viz_color(i, n, 1.0))
                p.setBrush(QBrush(g))
                p.drawRect(QRectF(x, r.bottom() - h, bw, h))
                if peaks and pk[i] > 0.02:
                    p.setBrush(self.viz_color(i, n, 1.0))
                    p.drawRect(QRectF(x, r.bottom() - pk[i] * r.height() - 2.0, bw, 1.6))
        p.restore()

    def draw_volume_bar(self, p: QPainter, r: QRectF):
        """Speaker icon + volume bar inside rect r (used by the visualizer screen and the menu pop-up)."""
        sp = QRectF(r.left(), r.top(), 16, r.height())
        cy = sp.center().y()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(INK)
        p.drawPolygon(poly([(sp.left(), cy - 2), (sp.left() + 4, cy - 2), (sp.left() + 9, cy - 6),
                            (sp.left() + 9, cy + 6), (sp.left() + 4, cy + 2), (sp.left(), cy + 2)]))
        bar = QRectF(r.left() + 22, r.top(), r.width() - 22, r.height())
        frac = max(0.0, min(1.0, float(self.cfg["volume"])))
        p.setPen(QPen(INK, 1.6))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(bar, 3, 3)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(INK)
        if frac > 0:
            p.drawRoundedRect(QRectF(bar.left() + 1, bar.top() + 1, max(4.0, (bar.width() - 2) * frac),
                                     bar.height() - 2), 2, 2)

    def draw_viz_screen(self, p: QPainter):
        """Full-screen visualizer: bars across the LCD, scrolling title below. Centre button = next style."""
        L = self.LCD
        t = self.current
        x, w, y = L.left() + 8, L.width() - 16, L.top()
        p.setPen(INK)
        p.setFont(self.f_main)
        if t is None:
            p.drawText(QRectF(L.left(), L.top() + self.HDR, L.width(), L.height() - self.HDR),
                       Qt.AlignmentFlag.AlignCenter, "No song playing")
            return
        self.draw_viz(p, QRectF(x, y + 34, w, 126))
        if self.vol_until:  # turning the wheel changes the volume: show it where the title is
            self.draw_volume_bar(p, QRectF(x, y + 169, w, 13))
            return
        p.setPen(INK)
        self._text(p, QRectF(x, y + 166, w, 20), f"{t.title} - {t.artist}", center=True, marquee=True,
                   t0=self.track_t0)

    # ------------------------------------------------------------------ Discord

    def open_discord(self):
        self.push(Screen("Discord", [
            Item("Presence", self.toggle_discord, value=lambda: "On" if self.cfg["discord"] else "Off"),
            Item("Status", None, value=lambda: self.rpc.status),
            Item("Client ID...", self.ask_discord_id, value=lambda: "Set" if self._discord_id() else "Missing"),
            Item("Image Key...", self.ask_discord_image, value=lambda: self.cfg["discord_image"] or "-"),
        ]))

    def _discord_id(self) -> str:
        return (self.cfg.get("discord_client_id") or os.environ.get("PYPOD_DISCORD_ID", "")).strip()

    def rpc_soon(self):
        self._rpc_timer.start()

    def toggle_discord(self):
        if not self.cfg["discord"] and not self._discord_id():
            self.ask_discord_id()
            if not self._discord_id():
                return  # no id, stay off
        self.cfg["discord"] = not self.cfg["discord"]
        save_config(self.cfg)
        self.discord_sync()
        self.update()

    def ask_discord_id(self):
        text, ok = QInputDialog.getText(
            self, "Discord Rich Presence",
            "Application (Client) ID from discord.com/developers/applications:",
            QLineEdit.EchoMode.Normal, self.cfg.get("discord_client_id", ""))
        if ok:
            self.cfg["discord_client_id"] = "".join(ch for ch in text if ch.isdigit())
            save_config(self.cfg)
            self.discord_sync()
            self.update()

    def ask_discord_image(self):
        text, ok = QInputDialog.getText(
            self, "Discord Rich Presence",
            "Name (key) of the art asset you uploaded to your Discord application:",
            QLineEdit.EchoMode.Normal, self.cfg.get("discord_image", "pypod"))
        if ok:
            self.cfg["discord_image"] = text.strip()
            save_config(self.cfg)
            self.discord_sync()
            self.update()

    def discord_activity(self) -> Optional[dict]:
        t = self.current
        if t is None or self.player.playbackState() == QMediaPlayer.PlaybackState.StoppedState:
            return None
        clip = lambda v: v.strip()[:120].ljust(2, ".")  # noqa: E731  (Discord wants 2..128 characters)
        playing = self.is_playing()
        act: dict = {
            "type": 2,  # "Listening to"
            "details": clip(t.title),
            "state": clip(t.artist if playing else f"Paused - {t.artist}"),
        }
        if self.cfg.get("discord_image"):
            act["assets"] = {"large_image": self.cfg["discord_image"], "large_text": clip(t.album)}
        dur = self._duration() / 1000.0
        if playing and dur > 0:
            now, pos = time.time(), self.player.position() / 1000.0
            act["timestamps"] = {"start": int(now - pos), "end": int(now + dur - pos)}
        return act

    def discord_sync(self):
        on = bool(self.cfg["discord"])
        self.rpc.configure(on, self._discord_id())
        self.rpc.post(self.discord_activity() if on else None)

    # ------------------------------------------------------------------ disc placeholder

    def has_disc(self) -> bool:
        """True when a song is loaded, has no cover, and art is not switched off."""
        return self.current is not None and self.cover is None and self.cfg["art"] != "Off"

    T_SLAM = 0.22  # seconds from release to impact

    def _advance_disc(self):
        """Advance the slam / spin physics once per paint."""
        now = time.monotonic()
        dt = min(0.2, now - self._disc_last)
        self._disc_last = now
        prev_t = self.disc_t
        self.disc_t = now - self.disc_t0 - 0.05
        if not self.has_disc():
            self.disc_speed = 0.0
            return
        if prev_t < self.T_SLAM <= self.disc_t:  # IMPACT: the disc is thrown into a violent spin
            self.disc_speed = max(self.disc_speed, 1000.0)
            if self.click_pct() > 0 and self.thud_fx is not None and self.stack[-1].kind == "now":
                self.thud_fx.play(self.cfg["click_engine"], self.click_pct() / 100.0)
        target = 220.0 if (self.is_playing() and self.disc_t > self.T_SLAM) else 0.0  # degrees per second
        self.disc_speed += (target - self.disc_speed) * min(1.0, dt * 2.5)  # spin-down / settle
        self.disc_angle = (self.disc_angle + self.disc_speed * dt) % 360.0
        if self.disc_t < 0.9 or target > 0 or self.disc_speed > 0.5:
            self._anim = True  # keep repainting while anything moves

    def draw_disc_case(self, p: QPainter, ar: QRectF):
        """A jewel case. The disc is slammed up into it, the case shakes, the disc rebounds and spins."""
        t, T = self.disc_t, self.T_SLAM
        tau = t - T  # time since impact
        if t < T:  # accelerating fall (ease-in): slow start, brutal arrival
            u = max(0.0, t) / T
            off = 40.0 * (1.0 - u * u)
        else:  # damped rebound: overshoots upward, then settles
            off = -9.0 * math.exp(-8.0 * tau) * math.sin(2 * math.pi * 6.0 * tau)
        dx = dy = 0.0
        if self.cfg["shake"] and 0.0 <= tau < 0.7:
            amp = 6.0 * math.exp(-7.0 * tau)
            dx = amp * math.sin(2 * math.pi * 38.0 * tau)
            dy = amp * 0.6 * math.cos(2 * math.pi * 31.0 * tau)
        p.save()
        p.translate(dx, dy)
        p.setClipRect(ar.adjusted(-14, -14, 10, 44))
        # case back
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(INK.red(), INK.green(), INK.blue(), 30))
        p.drawRoundedRect(ar, 3, 3)
        # disc
        c = QPointF(ar.center().x() + 3, ar.center().y() + off)
        g = QConicalGradient(c, self.disc_angle)
        if self.cfg["art"] == "Color":  # iridescent, like a real CD
            for i in range(13):
                g.setColorAt(i / 12.0, QColor.fromHsvF((i % 12) / 12.0, 0.28, 0.97))
        else:
            dark = QColor(INK.red(), INK.green(), INK.blue(), 150)
            for pos, col in ((0.0, LCD_HI), (0.12, dark), (0.25, LCD_HI), (0.5, dark),
                             (0.62, LCD_HI), (0.75, dark), (0.87, LCD_HI), (1.0, LCD_HI)):
                g.setColorAt(pos, col)
        p.setBrush(QBrush(g))
        p.setPen(QPen(INK, 1.4))
        p.drawEllipse(c, 33, 33)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(INK.red(), INK.green(), INK.blue(), 110), 1))
        p.drawEllipse(c, 16, 16)
        p.setBrush(LCD_HI)
        p.setPen(QPen(INK, 1.2))
        p.drawEllipse(c, 9, 9)
        p.setBrush(LCD_LO)
        p.drawEllipse(c, 3.5, 3.5)
        # case front: glass sheen, spine, outline
        gl = QLinearGradient(ar.topLeft(), ar.bottomRight())
        gl.setColorAt(0.0, QColor(255, 255, 255, 80))
        gl.setColorAt(0.45, QColor(255, 255, 255, 0))
        gl.setColorAt(0.55, QColor(255, 255, 255, 45))
        gl.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(gl))
        p.drawRoundedRect(ar, 3, 3)
        p.setBrush(QColor(INK.red(), INK.green(), INK.blue(), 90))
        p.drawRect(QRectF(ar.left(), ar.top(), 7, ar.height()))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(INK, 1.5))
        p.drawRoundedRect(ar, 3, 3)
        # impact flash + starburst
        if 0.0 <= tau < 0.25:
            b = tau / 0.25
            mid = ar.center()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, int(170 * (1.0 - b))))
            p.drawEllipse(mid, 22 + 26 * b, 22 + 26 * b)
            col = QColor(INK)
            col.setAlpha(int(255 * (1.0 - b)))
            p.setPen(QPen(col, 2.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            for i in range(12):
                a = math.radians(i * 30.0 + 8.0)
                r0, r1 = 34 + 8 * b, 38 + 18 * b
                p.drawLine(QPointF(mid.x() + r0 * math.cos(a), mid.y() + r0 * math.sin(a)),
                           QPointF(mid.x() + r1 * math.cos(a), mid.y() + r1 * math.sin(a)))
        p.restore()

    # ------------------------------------------------------------------ appearance

    def step_deg(self) -> float:
        return {"low": 22.0, "normal": 14.0, "high": 9.0}.get(self.cfg["sensitivity"], 14.0)

    def _commit(self):
        save_config(self.cfg)
        self.update()

    def cycle_cfg(self, key: str, options: list):
        cur = self.cfg.get(key)
        i = options.index(cur) if cur in options else -1
        self.cfg[key] = options[(i + 1) % len(options)]
        self._commit()

    def set_skin(self, name: str):
        self.cfg["skin"] = name
        self.cfg["rainbow"] = False
        self._commit()

    def toggle_rainbow(self, *_):
        self.cfg["rainbow"] = not self.cfg["rainbow"]
        self._commit()

    def pick_custom_color(self):
        c = QColorDialog.getColor(QColor(self.cfg["custom_color"]), self, "Pick a body colour")
        if c.isValid():
            self.cfg["custom_color"] = c.name()
            self.set_skin("Custom")

    def cycle_lcd(self):
        self.cycle_cfg("lcd", list(LCD_THEMES))
        apply_lcd(self.cfg["lcd"])
        self.update()

    def cycle_opacity(self):
        opts = [1.0, 0.9, 0.8, 0.7, 0.6]
        i = min(range(len(opts)), key=lambda k: abs(opts[k] - float(self.cfg["opacity"])))
        self.cfg["opacity"] = opts[(i + 1) % len(opts)]
        self.setWindowOpacity(self.cfg["opacity"])
        self._commit()

    def _advance_skin(self):
        """Fade the on-screen palette towards the current cover's colours; keep repainting while skins move."""
        now = time.monotonic()
        dt = min(0.2, now - self._skin_last)
        self._skin_last = now
        k = min(1.0, dt * 2.5)  # about a second to settle
        changing = False
        for cur, tgt in ((self.skin_true_cur, self.skin_true), (self.skin_vivid_cur, self.skin_vivid)):
            for i, t in enumerate(tgt):
                if i >= len(cur):
                    cur.append(QColor(t))
                elif (cur[i].red(), cur[i].green(), cur[i].blue()) != (t.red(), t.green(), t.blue()):
                    cur[i] = approach(cur[i], t, k)
                    changing = True
        if self.cfg["skin"] in COVER_SKINS and not self.cfg["rainbow"]:
            if changing or self.cfg["skin"] != "Cover Match":  # Vibrant and Lava are always in motion
                self._anim = True

    def _cover_skin(self, name: str):
        """(body, wheel, (top, mid, bottom) gradient, lava blob colours or None) for the cover-matching skins."""
        now = time.monotonic()
        if name == "Cover Match":
            c0, c1, c2 = self.skin_true_cur[0], self.skin_true_cur[1], self.skin_true_cur[2]
            grad = (lerp_color(c0, c2, 0.25).lighter(108), c0, lerp_color(c0, c1, 0.6))
            wheel = lerp_color(c0, c1, 0.25).darker(110)
            return c0, wheel, grad, None
        pal = [vibrant(c) for c in self.skin_vivid_cur]
        if name == "Cover Vibrant":  # the casing slowly drifts between the cover's colours
            ph = now * 0.22
            f = lambda k: 0.5 + 0.5 * math.sin(ph + k)  # noqa: E731
            top, mid, bot = stops_color(pal, f(0.0)), stops_color(pal, f(2.1)), stops_color(pal, f(4.2))
            wheel = lerp_color(mid, stops_color(pal, f(1.0)), 0.3).darker(108)
            return mid, wheel, (top, mid, bot), None
        base = self.skin_vivid_cur[0].darker(190)  # "Cover Lava": dark liquid with glowing blobs
        blobs = [pal[1], pal[2], pal[3], pal[0].lighter(125)]
        wheel = lerp_color(base, pal[1], 0.30)
        return base, wheel, (base.lighter(125), base, base.darker(125)), blobs

    def skin_colors(self) -> dict:
        """Every colour used for the casing and wheel, derived from the current skin."""
        cfg = self.cfg
        grad = lava = None
        if cfg["rainbow"]:
            speed = {"slow": 0.02, "medium": 0.05, "fast": 0.12}.get(cfg["rainbow_speed"], 0.05)
            hue = (time.monotonic() * speed) % 1.0
            body = QColor.fromHsvF(hue, 0.62, 0.94)
            wheel = QColor.fromHsvF(hue, 0.40, 0.97)
            icon = QColor("#555555")
        elif cfg["skin"] in COVER_SKINS:
            body, wheel, grad, lava = self._cover_skin(cfg["skin"])
            icon = QColor("#444444") if wheel.lightnessF() > 0.55 else QColor("#f0f0f0")
        elif cfg["skin"] == "Custom":
            body = QColor(cfg["custom_color"])
            if not body.isValid():
                body = QColor("#2f7fd6")
            wheel = body.darker(112)
            icon = QColor("#444444") if body.lightnessF() > 0.6 else QColor("#f0f0f0")
        else:
            b, w, i = SKINS.get(cfg["skin"], SKINS["White"])
            body, wheel, icon = QColor(b), QColor(w), QColor(i)
        if cfg["wheel_style"] == "white":
            wheel, icon = QColor("#efefef"), QColor("#7d7d7d")
        elif cfg["wheel_style"] == "black":
            wheel, icon = QColor("#222225"), QColor("#a0a0a6")
        bl = body.lightnessF() > 0.55
        wl = wheel.lightnessF() > 0.55
        out = {
            "body_top": body.lighter(112 if bl else 140),
            "body_mid": body,
            "body_bot": body.darker(112 if bl else 135),
            "body_edge": body.darker(150 if bl else 220),
            "body_hl": QColor(255, 255, 255, 210 if bl else 60),
            "ring_top": wheel.lighter(118 if wl else 150),
            "ring_bot": wheel.darker(108 if wl else 125),
            "disc_top": wheel.lighter(115 if wl else 145),
            "disc_bot": wheel.darker(103 if wl else 118),
            "edge": wheel.darker(140 if wl else 190),
            "line": wheel.darker(135 if wl else 190),
            "shine": QColor(255, 255, 255, 190 if wl else 45),
            "press": QColor(0, 0, 0, 38) if wl else QColor(255, 255, 255, 46),
            "icon": icon,
        }
        if grad is not None:
            out["body_top"], out["body_mid"], out["body_bot"] = grad
        if lava is not None:
            out["lava"] = lava
        return out

    # ------------------------------------------------------------------ painting

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        p.scale(self.scale_f, self.scale_f)
        p.translate(self.M, self.M)
        self._anim = False
        self._advance_skin()
        self.sc = self.skin_colors()
        self._advance_disc()
        self._advance_viz()
        self.draw_body(p)
        self.draw_screen(p)
        self.draw_wheel(p)
        p.end()

    def draw_lava(self, p: QPainter, body: QRectF, cols: list):
        """'Lava lamp' casing: soft blobs that drift, swell and stretch, clipped to the iPod's outline."""
        t = time.monotonic()
        p.save()
        clip = QPainterPath()
        clip.addRoundedRect(body, 30, 30)
        p.setClipPath(clip)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(7):
            ph = i * 2.399  # golden-angle offsets: the blobs never move in step
            x = self.W * (0.5 + 0.38 * math.sin(t * (0.21 + 0.017 * i) + ph))
            y = self.H * (0.5 + 0.50 * math.sin(t * (0.15 + 0.013 * i) + ph * 1.7))
            r = 62 + 34 * (0.5 + 0.5 * math.sin(t * 0.27 + ph * 2.0)) + 5 * (i % 3)
            stretch = 1.0 + 0.30 * math.sin(t * 0.33 + ph)  # they squash and stretch as they move
            c = cols[i % len(cols)]
            g = QRadialGradient(QPointF(0, 0), r)
            for pos, alpha in ((0.0, 235), (0.55, 170), (1.0, 0)):
                col = QColor(c)
                col.setAlpha(alpha)
                g.setColorAt(pos, col)
            p.save()
            p.translate(x, y)
            p.scale(1.0 / stretch, stretch)
            p.setBrush(QBrush(g))
            p.drawEllipse(QPointF(0, 0), r, r)
            p.restore()
        p.restore()

    def draw_body(self, p: QPainter):
        c = self.sc
        body = QRectF(0, 0, self.W, self.H)
        p.setPen(Qt.PenStyle.NoPen)
        if self.cfg["shadow"]:
            for i in range(11):  # soft drop shadow
                p.setBrush(QColor(0, 0, 0, 7))
                p.drawRoundedRect(body.adjusted(-i, -i + 4, i, i + 4), 30 + i, 30 + i)
        g = QLinearGradient(0, 0, self.W, self.H)
        g.setColorAt(0.0, c["body_top"])
        g.setColorAt(0.5, c["body_mid"])
        g.setColorAt(1.0, c["body_bot"])
        p.setBrush(QBrush(g))
        p.setPen(QPen(c["body_edge"], 2.2))
        p.drawRoundedRect(body, 30, 30)
        if c.get("lava"):
            self.draw_lava(p, body, c["lava"])
            p.setBrush(Qt.BrushStyle.NoBrush)  # redraw the outline over the blobs
            p.setPen(QPen(c["body_edge"], 2.2))
            p.drawRoundedRect(body, 30, 30)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(c["body_hl"], 1.6))
        p.drawRoundedRect(body.adjusted(3, 3, -3, -3), 27, 27)

    def draw_screen(self, p: QPainter):
        # bezel
        g = QLinearGradient(0, self.BEZEL.top(), 0, self.BEZEL.bottom())
        g.setColorAt(0, QColor("#6a6a6a"))
        g.setColorAt(1, QColor("#3a3a3a"))
        p.setBrush(QBrush(g))
        p.setPen(QPen(QColor("#777"), 1))
        p.drawRoundedRect(self.BEZEL, 8, 8)
        # LCD
        L = self.LCD
        g = QLinearGradient(0, L.top(), 0, L.bottom())
        g.setColorAt(0, LCD_HI)
        g.setColorAt(1, LCD_LO)
        p.setBrush(QBrush(g))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(L, 3, 3)

        p.save()
        clip = QPainterPath()
        clip.addRoundedRect(L, 3, 3)
        p.setClipPath(clip)
        scr = self.stack[-1]
        self.draw_header(p, scr)
        if scr.kind == "now":
            self.draw_now(p)
        elif scr.kind == "viz":
            self.draw_viz_screen(p)
        else:
            self.draw_menu(p, scr)
        if self.scan_count is not None:
            p.setFont(self.f_small)
            r = QRectF(L.left() + 24, L.bottom() - 30, L.width() - 48, 22)
            p.setBrush(LCD_HI)
            p.setPen(QPen(INK, 1.5))
            p.drawRoundedRect(r, 4, 4)
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, f"Scanning... {self.scan_count}")
        if self.vol_until and scr.kind == "menu":  # volume pop-up (keys + / - work on menus too)
            r = QRectF(L.left() + 14, L.bottom() - 32, L.width() - 28, 26)
            p.setBrush(LCD_HI)
            p.setPen(QPen(INK, 1.5))
            p.drawRoundedRect(r, 4, 4)
            self.draw_volume_bar(p, QRectF(r.left() + 8, r.top() + 6, r.width() - 16, 13))
        # inner shadow + glass
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(0, 0, 0, 70), 3))
        p.drawRoundedRect(L, 3, 3)
        gl = QLinearGradient(0, L.top(), 0, L.top() + 70)
        gl.setColorAt(0, QColor(255, 255, 255, 55))
        gl.setColorAt(1, QColor(255, 255, 255, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(gl))
        p.drawRect(QRectF(L.left(), L.top(), L.width(), 70))
        p.restore()

    # -- LCD pieces

    def _text(self, p: QPainter, rect: QRectF, text: str, center=False, marquee=False, t0=None):
        fm = QFontMetrics(p.font())
        w = fm.horizontalAdvance(text)
        vc = Qt.AlignmentFlag.AlignVCenter
        if w <= rect.width():
            al = Qt.AlignmentFlag.AlignHCenter if center else Qt.AlignmentFlag.AlignLeft
            p.drawText(rect, vc | al, text)
        elif marquee:
            self._anim = True
            gap = 36
            span = w + gap
            off = max(0.0, time.monotonic() - (self.marquee_t0 if t0 is None else t0) - 1.0) * 38.0 % span
            p.save()
            p.setClipRect(rect, Qt.ClipOperation.IntersectClip)
            for k in (0, 1):
                p.drawText(QRectF(rect.left() - off + k * span, rect.top(), w + 4, rect.height()),
                           vc | Qt.AlignmentFlag.AlignLeft, text)
            p.restore()
        else:
            p.drawText(rect, vc | Qt.AlignmentFlag.AlignLeft,
                       fm.elidedText(text, Qt.TextElideMode.ElideRight, int(rect.width())))

    def draw_header(self, p: QPainter, scr: Screen):
        L = self.LCD
        cy = L.top() + self.HDR / 2
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(INK)
        x = L.left() + 8
        state = self.player.playbackState()
        if state == QMediaPlayer.PlaybackState.PlayingState:
            p.drawPolygon(poly([(x, cy - 5), (x, cy + 5), (x + 9, cy)]))
        elif state == QMediaPlayer.PlaybackState.PausedState:
            p.drawRect(QRectF(x, cy - 5, 3, 10))
            p.drawRect(QRectF(x + 6, cy - 5, 3, 10))
        # mini cover (not on the Now Playing screen, which has the big one)
        mini = self.art(40) if scr.kind != "now" else None
        if mini is not None:
            r = QRectF(x + 14, cy - 10, 20, 20)
            p.drawImage(r, mini)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(INK, 1))
            p.drawRect(r)
        elif scr.kind != "now" and self.has_disc():
            c = QPointF(x + 24, cy)
            p.setBrush(LCD_HI)
            p.setPen(QPen(INK, 1.3))
            p.drawEllipse(c, 9, 9)
            p.drawEllipse(c, 2.5, 2.5)
            a = math.radians(self.disc_angle)  # a notch that turns while the disc spins
            p.drawLine(QPointF(c.x() + 4.5 * math.cos(a), c.y() + 4.5 * math.sin(a)),
                       QPointF(c.x() + 8.5 * math.cos(a), c.y() + 8.5 * math.sin(a)))
        # title
        p.setPen(INK)
        p.setFont(self.f_main)
        self._text(p, QRectF(L.left() + 46, L.top(), L.width() - 90, self.HDR), scr.title, center=True)
        # battery
        bx, by = L.right() - 34, cy - 5
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(INK, 1.3))
        p.drawRect(QRectF(bx, by, 22, 10))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(INK)
        p.drawRect(QRectF(bx + 22, cy - 2, 2, 4))
        for i in range(4):
            p.drawRect(QRectF(bx + 2 + i * 5, by + 2, 4, 6))
        p.setPen(QPen(INK, 1.2))
        p.drawLine(QPointF(L.left(), L.top() + self.HDR - 1), QPointF(L.right(), L.top() + self.HDR - 1))

    def draw_ticker(self, p: QPainter, r: QRectF):
        t = self.current
        p.save()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(INK.red(), INK.green(), INK.blue(), 34))
        p.drawRect(r)
        p.setPen(QPen(INK, 1))
        p.drawLine(r.bottomLeft(), r.bottomRight())
        p.setFont(self.f_small)
        self._text(p, r.adjusted(6, 0, -6, -1), f"{t.title} - {t.artist}", center=True, marquee=True,
                   t0=self.track_t0)
        p.restore()

    def draw_menu(self, p: QPainter, scr: Screen):
        L = self.LCD
        n = len(scr.items)
        y0 = L.top() + self.HDR
        if self.ticker_on():
            self.draw_ticker(p, QRectF(L.left(), y0, L.width(), 19))
            y0 += 19
        vis = self.vis()
        p.setFont(self.f_main)
        fm = QFontMetrics(self.f_main)
        if n == 0:
            p.setPen(INK)
            p.drawText(QRectF(L.left(), y0, L.width(), 60), Qt.AlignmentFlag.AlignCenter, "No items")
            return
        if scr.sel < scr.top:
            scr.top = scr.sel
        elif scr.sel >= scr.top + vis:
            scr.top = scr.sel - vis + 1
        right = L.right() - (10 if n > vis else 0)
        for row in range(vis):
            i = scr.top + row
            if i >= n:
                break
            it = scr.items[i]
            y = y0 + row * self.ROW
            sel = i == scr.sel
            r = QRectF(L.left(), y, right - L.left(), self.ROW)
            if sel:
                p.fillRect(r, INK)
            col = LCD_TEXT_INV if sel else INK
            p.setPen(col)
            val = it.value() if it.value else ""
            vw = fm.horizontalAdvance(val) + (10 if val else 0)
            reserve = 20 if it.arrow else 6
            self._text(p, QRectF(r.left() + 8, y, r.width() - 8 - reserve - vw, self.ROW), it.label, marquee=sel)
            if val:
                p.drawText(QRectF(r.right() - reserve - vw, y, vw, self.ROW),
                           Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, val)
            if it.arrow:
                cx, cy = r.right() - 11, y + self.ROW / 2
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(col)
                p.drawPolygon(poly([(cx - 3, cy - 5), (cx + 3, cy), (cx - 3, cy + 5)]))
        if n > vis:  # scrollbar
            th = vis * self.ROW
            tx = L.right() - 7
            p.setPen(QPen(INK, 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(tx, y0 + 2, 4, th - 4))
            hh = max(10.0, (th - 4) * vis / n)
            hy = y0 + 2 + (th - 4 - hh) * (scr.sel / max(1, n - 1))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(INK)
            p.drawRect(QRectF(tx, hy, 4, hh))

    def draw_now(self, p: QPainter):
        L = self.LCD
        t = self.current
        p.setPen(INK)
        if not t:
            p.setFont(self.f_main)
            p.drawText(QRectF(L.left(), L.top() + self.HDR, L.width(), L.height() - self.HDR),
                       Qt.AlignmentFlag.AlignCenter, "No song playing")
            return
        x, w = L.left() + 8, L.width() - 16
        y = L.top()
        vc_l = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
        counter = f"{self.opos + 1} of {len(self.order)}"
        art = self.art(160)
        if art is not None or self.has_disc():  # cover (or disc case) on the left, text on the right
            ar = QRectF(x, y + 34, 80, 80)
            if art is not None:
                p.drawImage(ar, art)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(INK, 1.5))
                p.drawRect(ar)
            else:
                self.draw_disc_case(p, ar)
            tx, tw = x + 90, w - 90
            p.setFont(self.f_small)
            p.drawText(QRectF(tx, y + 32, tw, 16), vc_l, counter)
            p.setFont(self.f_main)
            self._text(p, QRectF(tx, y + 50, tw, 20), t.title, marquee=True)
            self._text(p, QRectF(tx, y + 74, tw, 20), t.artist, marquee=True)
            self._text(p, QRectF(tx, y + 98, tw, 20), t.album, marquee=True)
            if self.cfg["viz"]:
                self.draw_viz(p, QRectF(x, y + 119, w, 27))
        else:  # classic centred layout
            p.setFont(self.f_small)
            p.drawText(QRectF(x, y + 35, w, 16), vc_l, counter)
            p.setFont(self.f_main)
            self._text(p, QRectF(x, y + 61, w, 20), t.title, center=True, marquee=True)
            self._text(p, QRectF(x, y + 86, w, 20), t.artist, center=True, marquee=True)
            self._text(p, QRectF(x, y + 111, w, 20), t.album, center=True, marquee=True)
            if self.cfg["viz"]:
                self.draw_viz(p, QRectF(x, y + 134, w, 13))

        pos, dur = self.player.position(), self._duration()
        bar = QRectF(x, y + 150, w, 13)
        if self.vol_until:  # volume overlay replaces the progress bar
            sp = QRectF(x, y + 150, 16, 13)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(INK)
            p.drawPolygon(poly([(sp.left(), sp.center().y() - 2), (sp.left() + 4, sp.center().y() - 2),
                                (sp.left() + 9, sp.center().y() - 6), (sp.left() + 9, sp.center().y() + 6),
                                (sp.left() + 4, sp.center().y() + 2), (sp.left(), sp.center().y() + 2)]))
            bar = QRectF(x + 22, y + 150, w - 22, 13)
            frac = self.cfg["volume"]
        else:
            frac = (pos / dur) if dur > 0 else 0.0
        frac = max(0.0, min(1.0, frac))
        p.setPen(QPen(INK, 1.6))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(bar, 3, 3)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(INK)
        if frac > 0:
            p.drawRoundedRect(QRectF(bar.left() + 1, bar.top() + 1, max(4.0, (bar.width() - 2) * frac), bar.height() - 2), 2, 2)
        if self.scrub and not self.vol_until:  # scrub handle
            mx = bar.left() + 1 + (bar.width() - 2) * frac
            p.setBrush(LCD_HI)
            p.setPen(QPen(INK, 1.6))
            p.drawPolygon(poly([(mx, bar.top() - 5), (mx + 5, bar.center().y()), (mx, bar.bottom() + 5), (mx - 5, bar.center().y())]))
        p.setPen(INK)
        p.setFont(self.f_main)
        p.drawText(QRectF(x, y + 168, w, 20), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, fmt_time(pos))
        p.drawText(QRectF(x, y + 168, w, 20), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
                   "-" + fmt_time(max(0, dur - pos)) if dur > 0 else "-0:00")

    # -- click wheel

    def _sector(self, start: float) -> QPainterPath:
        cx, cy = self.CX, self.CY
        outer = QRectF(cx - self.R_OUT, cy - self.R_OUT, 2 * self.R_OUT, 2 * self.R_OUT)
        inner = QRectF(cx - self.R_DISC, cy - self.R_DISC, 2 * self.R_DISC, 2 * self.R_DISC)
        path = QPainterPath()
        path.arcMoveTo(outer, start)
        path.arcTo(outer, start, 90)
        path.arcTo(inner, start + 90, -90)
        path.closeSubpath()
        return path

    def draw_wheel(self, p: QPainter):
        c = self.sc
        cx, cy = self.CX, self.CY
        ctr = QPointF(cx, cy)
        # outer ring
        g = QRadialGradient(QPointF(cx - 30, cy - 70), self.R_OUT * 1.6)
        g.setColorAt(0, c["ring_top"])
        g.setColorAt(1, c["ring_bot"])
        p.setBrush(QBrush(g))
        p.setPen(QPen(c["edge"], 1.6))
        p.drawEllipse(ctr, self.R_OUT, self.R_OUT)
        # pressed sector
        starts = {"menu": 45, "next": -45, "play": -135, "prev": 135}
        if self.pressed in starts:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c["press"])
            p.drawPath(self._sector(starts[self.pressed]))
        # dividers
        p.setPen(QPen(c["line"], 1.3))
        for ang in (45, 135, 225, 315):
            r = math.radians(ang)
            p.drawLine(QPointF(cx + self.R_DISC * math.cos(r), cy - self.R_DISC * math.sin(r)),
                       QPointF(cx + self.R_OUT * math.cos(r), cy - self.R_OUT * math.sin(r)))
        # scroll disc
        g = QRadialGradient(QPointF(cx - 25, cy - 40), self.R_DISC * 1.5)
        g.setColorAt(0, c["disc_top"])
        g.setColorAt(1, c["disc_bot"])
        p.setBrush(QBrush(g))
        p.setPen(QPen(c["edge"], 1.6))
        p.drawEllipse(ctr, self.R_DISC, self.R_DISC)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(c["shine"], 1.6))
        p.drawEllipse(ctr, self.R_DISC - 3, self.R_DISC - 3)
        # centre button
        g = QRadialGradient(QPointF(cx - 10, cy - 14), self.R_BTN * 1.6)
        g.setColorAt(0, c["disc_top"])
        g.setColorAt(1, c["ring_bot"])
        p.setBrush(QBrush(g))
        p.setPen(QPen(c["edge"], 1.6))
        p.drawEllipse(ctr, self.R_BTN, self.R_BTN)
        if self.pressed == "center":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c["press"])
            p.drawEllipse(ctr, self.R_BTN, self.R_BTN)
        # labels / icons
        p.setPen(c["icon"])
        p.setFont(self.f_label)
        p.drawText(QRectF(cx - 40, cy - 149, 80, 22), Qt.AlignmentFlag.AlignCenter, "menu")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c["icon"])
        d = 137
        x, y = cx - d, cy  # prev
        p.drawRect(QRectF(x - 8, y - 6, 2, 12))
        p.drawPolygon(poly([(x - 5, y), (x + 1, y - 6), (x + 1, y + 6)]))
        p.drawPolygon(poly([(x + 1, y), (x + 7, y - 6), (x + 7, y + 6)]))
        x = cx + d  # next
        p.drawRect(QRectF(x + 6, y - 6, 2, 12))
        p.drawPolygon(poly([(x + 5, y), (x - 1, y - 6), (x - 1, y + 6)]))
        p.drawPolygon(poly([(x - 1, y), (x - 7, y - 6), (x - 7, y + 6)]))
        x, y = cx, cy + d  # play / pause
        p.drawPolygon(poly([(x - 9, y - 6), (x - 9, y + 6), (x - 1, y)]))
        p.drawRect(QRectF(x + 2, y - 6, 3, 12))
        p.drawRect(QRectF(x + 7, y - 6, 3, 12))


# --------------------------------------------------------------------------- entry point


def sound_diagnose() -> int:
    """`pypod.py --sound-test`: prints what the sound set-up looks like and plays a click both ways."""
    app = QApplication([sys.argv[0]])

    def wait(sec: float) -> None:
        end = time.monotonic() + sec
        while time.monotonic() < end:
            app.processEvents()
            time.sleep(0.01)

    cfg = load_config()
    print(f"config file : {CONFIG_FILE} (exists: {CONFIG_FILE.exists()})")
    print(f"click volume: {cfg.get('click_volume')}%   <- 0 means no clicks")
    print(f"click engine: {cfg.get('click_engine')}")
    try:
        outs = QMediaDevices.audioOutputs()
        default = QMediaDevices.defaultAudioOutput()
        print(f"audio output: default = {default.description()!r}; {len(outs)} device(s): "
              + ", ".join(repr(o.description()) for o in outs))
    except Exception as exc:
        print(f"audio output: could not list devices ({exc})")
    d = sfx_dir()
    make_click_wav(d / "click.wav")
    sfx = Sfx(d / "click.wav")
    wait(1.5)
    try:
        print(f"Qt effect   : status = {sfx.fx.status()}, loaded = {sfx.fx.isLoaded()}")
    except Exception as exc:
        print(f"Qt effect   : unavailable ({exc})")
    print(f"system play : {sfx.system_desc()}")
    print("-> playing 3 clicks with Qt ...")
    for _ in range(3):
        sfx.play("Qt", 0.5)
        wait(0.4)
    print("-> playing 3 clicks with the system player ...")
    for _ in range(3):
        sfx.play("System", 0.5)
        wait(0.4)
    print("Done. Did you hear the first set, the second set, both or neither?")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="pyPod - iPod-style music player")
    ap.add_argument("--version", action="version", version="pyPod 2.0")
    ap.add_argument("--folder", help="music folder (saved for next start)")
    ap.add_argument("--scale", type=float, help="window scale, e.g. 1.25")
    ap.add_argument("--on-top", action="store_true", help="start with Always on Top enabled")
    ap.add_argument("--sound-test", action="store_true", help="check the click sounds and exit")
    args, qt_args = ap.parse_known_args()

    if args.sound_test:
        return sound_diagnose()
    cfg = load_config()
    if args.folder:
        cfg["folder"] = str(Path(args.folder).expanduser().resolve())
    if args.scale:
        cfg["scale"] = max(0.5, min(3.0, args.scale))
    if args.on_top:
        cfg["always_on_top"] = True

    app = QApplication([sys.argv[0], *qt_args])
    app.setApplicationName("pypod")
    app.setDesktopFileName("pypod")
    app.setWindowIcon(QIcon(QPixmap.fromImage(draw_icon(256))))
    win = IPod(cfg, pick_font_family())
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
