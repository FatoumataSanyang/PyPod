@echo off
rem Starts pyPod straight from the source folder (first run creates a .venv and installs the dependencies).
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Setting up pyPod for the first time, one moment...
  py -3 -m venv .venv 2>nul || python -m venv .venv
  if errorlevel 1 (
    echo Python 3.9+ was not found. Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^).
    pause
    exit /b 1
  )
  ".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
  ".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
  ".venv\Scripts\python.exe" -m pip install --quiet numpy miniaudio
)
start "" ".venv\Scripts\pythonw.exe" pypod.py %*
