#!/usr/bin/env bash
# Builds pyPod-x86_64.AppImage  (run on Linux, needs python3 >= 3.9 and internet access).
# Tip: build on the OLDEST distro you want to support (e.g. Ubuntu 22.04) for best compatibility.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

ARCH="$(uname -m)"
VENV=.build-venv
APPDIR=build/AppDir

echo "==> Creating build virtualenv"
python3 -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt pyinstaller
pip install --quiet numpy || echo "note: numpy not installed (visualizer falls back to slower code)"
pip install --quiet miniaudio || echo "note: miniaudio not installed (visualizer will use ffmpeg from the host)"

echo "==> Freezing with PyInstaller"
rm -rf build dist
EXCLUDES=()
for m in QtWebEngineCore QtWebEngineWidgets QtWebEngineQuick QtWebView Qt3DCore Qt3DRender Qt3DInput \
         Qt3DLogic Qt3DAnimation Qt3DExtras QtQuick3D QtCharts QtDataVisualization QtSql QtTest \
         QtDesigner QtHelp QtPdf QtPdfWidgets QtBluetooth QtNfc QtSensors QtSerialPort QtRemoteObjects \
         QtPositioning QtLocation QtScxml QtSpatialAudio QtGraphs; do
  EXCLUDES+=(--exclude-module "PySide6.$m")
done
EXTRA_DATA=()
[ -d assets ] && EXTRA_DATA+=(--add-data "assets:assets")
python -c "import miniaudio" 2>/dev/null && EXTRA_DATA+=(--collect-all miniaudio)
pyinstaller --noconfirm --clean --onedir --name pypod "${EXCLUDES[@]}" ${EXTRA_DATA[@]+"${EXTRA_DATA[@]}"} pypod.py >/dev/null

echo "==> Assembling AppDir"
mkdir -p "$APPDIR/usr/lib"
cp -a dist/pypod "$APPDIR/usr/lib/pypod"
cat > "$APPDIR/AppRun" <<'EOF'
#!/bin/sh
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/lib/pypod/pypod" "$@"
EOF
chmod +x "$APPDIR/AppRun"
cp packaging/pypod.desktop "$APPDIR/pypod.desktop"
QT_QPA_PLATFORM=offscreen python packaging/make_icon.py "$APPDIR/pypod.png"
ln -sf pypod.png "$APPDIR/.DirIcon"

echo "==> Fetching appimagetool"
TOOL="build/appimagetool-$ARCH.AppImage"
if [ ! -x "$TOOL" ]; then
  curl -fL -o "$TOOL" "https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-$ARCH.AppImage"
  chmod +x "$TOOL"
fi

echo "==> Building AppImage"
ARCH="$ARCH" "$TOOL" --appimage-extract-and-run "$APPDIR" "pyPod-$ARCH.AppImage"
echo "Done: $(pwd)/pyPod-$ARCH.AppImage"
