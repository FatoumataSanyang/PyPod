#!/usr/bin/env bash
# Installs a "pyPod" launcher into your application menu so you can pin it to the taskbar/panel.
# Works on KDE Plasma and GNOME (Nobara, Fedora, Ubuntu, ...). Re-run any time; use --uninstall to remove.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
HERE="$(pwd)"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"

if [ "${1:-}" = "--uninstall" ]; then
  rm -f "$APPS/pypod.desktop" "$ICONS/pypod.png"
  update-desktop-database "$APPS" 2>/dev/null || true
  echo "Launcher removed."; exit 0
fi

# 1) Python environment with dependencies
if [ ! -x .venv/bin/python ]; then
  echo "==> Creating virtualenv and installing dependencies"
  python3 -m venv .venv
  .venv/bin/pip install --quiet --upgrade pip
  .venv/bin/pip install --quiet -r requirements.txt
fi

# 1b) Optional extras for the visualizer (ffmpeg on PATH also works instead of miniaudio)
.venv/bin/python -c "import numpy" 2>/dev/null || .venv/bin/pip install --quiet numpy >/dev/null 2>&1 \
  || echo "note: numpy not installed (the visualizer will use a slower fallback)"
.venv/bin/python -c "import miniaudio" 2>/dev/null || .venv/bin/pip install --quiet miniaudio >/dev/null 2>&1 \
  || echo "note: miniaudio not installed (the visualizer will use ffmpeg if it is installed)"

# 2) Icon
mkdir -p "$ICONS" "$APPS"
QT_QPA_PLATFORM=offscreen .venv/bin/python packaging/make_icon.py "$ICONS/pypod.png"

# 3) Desktop entry. QT_QPA_PLATFORM=xcb makes "Always on Top" work on Wayland sessions
#    (it runs through XWayland). Delete the "env QT_QPA_PLATFORM=xcb" part if you don't need that.
cat > "$APPS/pypod.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=pyPod
GenericName=Music Player
Comment=iPod-style MP3 player
Exec=env QT_QPA_PLATFORM=xcb "$HERE/.venv/bin/python" "$HERE/pypod.py"
Path=$HERE
Icon=pypod
Terminal=false
Categories=AudioVideo;Audio;Player;
StartupWMClass=pypod
EOF
chmod +x "$APPS/pypod.desktop"
update-desktop-database "$APPS" 2>/dev/null || true
gtk-update-icon-cache -q "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor" 2>/dev/null || true
kbuildsycoca6 >/dev/null 2>&1 || true   # refresh KDE's menu cache (no-op elsewhere)

echo "Done. Search for \"pyPod\" in your app menu, then right-click it -> Pin to Task Manager (KDE) / Add to Favorites (GNOME)."
