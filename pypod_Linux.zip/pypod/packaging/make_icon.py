#!/usr/bin/env python3
"""Draws a 256x256 pyPod icon. Usage: make_icon.py OUTPUT.png"""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QGuiApplication, QImage, QLinearGradient, QPainter, QPen

app = QGuiApplication([])
img = QImage(256, 256, QImage.Format.Format_ARGB32)
img.fill(Qt.GlobalColor.transparent)
p = QPainter(img)
p.setRenderHint(QPainter.RenderHint.Antialiasing)

body = QRectF(52, 12, 152, 232)
g = QLinearGradient(0, 12, 256, 244)
g.setColorAt(0, QColor("#fbfbfb"))
g.setColorAt(1, QColor("#d8d8d8"))
p.setBrush(g)
p.setPen(QPen(QColor("#8c8c8c"), 3))
p.drawRoundedRect(body, 18, 18)

p.setBrush(QColor("#4a4a4a"))
p.setPen(Qt.PenStyle.NoPen)
p.drawRoundedRect(QRectF(66, 26, 124, 84), 6, 6)
p.setBrush(QColor("#c5d5ea"))
p.drawRoundedRect(QRectF(70, 30, 116, 76), 3, 3)
p.setBrush(QColor("#26334a"))
p.drawRect(QRectF(78, 80, 100, 8))

c = QPointF(128, 178)
p.setBrush(QColor("#ececec"))
p.setPen(QPen(QColor("#9a9a9a"), 2))
p.drawEllipse(c, 56, 56)
p.setBrush(QColor("#fafafa"))
p.drawEllipse(c, 42, 42)
p.setBrush(QColor("#e8e8e8"))
p.drawEllipse(c, 17, 17)
p.end()

img.save(sys.argv[1] if len(sys.argv) > 1 else "pypod.png")
